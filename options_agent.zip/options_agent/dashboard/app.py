"""
Options Trading Agent — Streamlit Simulation Dashboard

Run:
    cd options_agent
    streamlit run dashboard/app.py
"""

from __future__ import annotations

import os
import sys

# ── Ensure project root is on path ──
_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _root not in sys.path:
    sys.path.insert(0, _root)

import json
import math
from datetime import date, datetime, timedelta, timezone
from typing import Optional

import numpy as np
import pandas as pd
import plotly.graph_objects as go
import streamlit as st
import yfinance as yf

from src.market_analyzer import MarketAnalyzer
from src.models.market_data import MarketIndicators, MarketRegime
from src.models.options import Greeks, OptionContract, OptionLeg, OptionOrder
from src.models.portfolio import (
    AccountInfo,
    PortfolioSummary,
    RiskAssessment,
    StockPosition,
)
from src.risk_manager import RiskManager
from src.strategies import STRATEGIES
from src.strategies.buy_call import BuyCallStrategy
from src.strategies.buy_put import BuyPutStrategy
from src.strategy_selector import REGIME_STRATEGY_MAP, StrategySelector
from src.entry_analyzer import EntryAnalyzer, EntrySignal
from src.execution_guide import build_execution_guide
from src.opening_range import OpeningRangeAnalyzer, BreakoutDirection
from src.recent_momentum import RecentMomentumAnalyzer
from src.utils.quality_scorer import compute_quality_score

# ── Page config ──────────────────────────────────────────────────

st.set_page_config(
    page_title="Options Trading Simulator",
    page_icon="📈",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── Constants ────────────────────────────────────────────────────

REGIME_LABELS = {
    MarketRegime.LOW_VOL_BULLISH: ("Low Vol · Bullish", "🟢"),
    MarketRegime.LOW_VOL_NEUTRAL: ("Low Vol · Neutral", "🔵"),
    MarketRegime.RANGE_BOUND_HV: ("Range-Bound · High Vol", "🟡"),
    MarketRegime.HIGH_VOL_BEARISH: ("High Vol · Bearish", "🔴"),
    MarketRegime.TRENDING_BEARISH: ("Trending · Bearish", "🔻"),
}


STRATEGY_DESCRIPTIONS = {
    "buy_call": {
        "name": "Buy Call (Scalp)",
        "icon": "🚀",
        "desc": "Buy ATM calls on bullish breakout after 60-min opening range. Intraday scalp — close by EOD.",
        "color": "#00d2ff",
    },
    "buy_put": {
        "name": "Buy Put (Scalp)",
        "icon": "💥",
        "desc": "Buy ATM puts on bearish breakout after 60-min opening range. Intraday scalp — close by EOD.",
        "color": "#ff6b6b",
    },
}


# ══════════════════════════════════════════════════════════════════
#  HELPER FUNCTIONS
# ══════════════════════════════════════════════════════════════════

# ── Mock data for offline / demo mode ─────────────────────────────

MOCK_INDICATORS: dict[str, dict] = {
    "AAPL": {
        "symbol": "AAPL", "current_price": 190.0, "vix": 15.0, "rsi_14": 55.0,
        "sma_20": 188.0, "sma_50": 185.0, "sma_200": 175.0,
        "bb_upper": 195.0, "bb_middle": 188.0, "bb_lower": 181.0,
        "macd": 1.5, "macd_signal": 1.0, "macd_histogram": 0.5, "atr_14": 3.2,
        "volume": 55_000_000, "volume_sma_20": 50_000_000,
        "next_earnings_date": "2026-07-25", "days_to_earnings": 100,
    },
    "SPY": {
        "symbol": "SPY", "current_price": 440.0, "vix": 25.0, "rsi_14": 50.0,
        "sma_20": 438.0, "sma_50": 435.0, "sma_200": 420.0,
        "bb_upper": 450.0, "bb_middle": 438.0, "bb_lower": 426.0,
        "macd": 0.3, "macd_signal": 0.2, "macd_histogram": 0.1, "atr_14": 6.5,
        "volume": 70_000_000, "volume_sma_20": 65_000_000,
        "next_earnings_date": None, "days_to_earnings": None,
    },
    "TSLA": {
        "symbol": "TSLA", "current_price": 165.0, "vix": 35.0, "rsi_14": 72.0,
        "sma_20": 170.0, "sma_50": 178.0, "sma_200": 180.0,
        "bb_upper": 180.0, "bb_middle": 170.0, "bb_lower": 160.0,
        "macd": -2.0, "macd_signal": -1.0, "macd_histogram": -1.0, "atr_14": 5.5,
        "volume": 90_000_000, "volume_sma_20": 75_000_000,
        "next_earnings_date": "2026-07-20", "days_to_earnings": 95,
    },
    "MSFT": {
        "symbol": "MSFT", "current_price": 410.0, "vix": 12.0, "rsi_14": 35.0,
        "sma_20": 408.0, "sma_50": 412.0, "sma_200": 390.0,
        "bb_upper": 420.0, "bb_middle": 408.0, "bb_lower": 396.0,
        "macd": 0.2, "macd_signal": 0.1, "macd_histogram": 0.1, "atr_14": 5.0,
        "volume": 30_000_000, "volume_sma_20": 35_000_000,
        "next_earnings_date": "2026-07-22", "days_to_earnings": 97,
    },
}


def _mock_indicators(symbol: str, timeframe: str = "daily") -> dict:
    """Return mock indicators — use AAPL data as fallback for unknown symbols."""
    data = MOCK_INDICATORS.get(symbol, MOCK_INDICATORS["AAPL"]).copy()
    data["symbol"] = symbol
    data["timestamp"] = datetime.now(timezone.utc).isoformat()
    data["timeframe"] = timeframe

    # Adjust indicators slightly per timeframe to simulate different resolutions
    if timeframe == "15min":
        # Intraday: tighter bands, more volatile RSI, smaller ATR, lower per-bar volume
        data["atr_14"] = round(data["atr_14"] * 0.15, 2)     # 15-min ATR is ~15% of daily
        data["bb_upper"] = round(data["bb_middle"] + (data["bb_upper"] - data["bb_middle"]) * 0.4, 2)
        data["bb_lower"] = round(data["bb_middle"] - (data["bb_middle"] - data["bb_lower"]) * 0.4, 2)
        data["volume"] = int(data["volume"] * 0.04)           # ~1/26 of daily volume per 15-min bar
        data["volume_sma_20"] = int(data["volume_sma_20"] * 0.04)
    elif timeframe == "1hour":
        # Hourly: somewhat tighter
        data["atr_14"] = round(data["atr_14"] * 0.35, 2)
        data["bb_upper"] = round(data["bb_middle"] + (data["bb_upper"] - data["bb_middle"]) * 0.6, 2)
        data["bb_lower"] = round(data["bb_middle"] - (data["bb_middle"] - data["bb_lower"]) * 0.6, 2)
        data["volume"] = int(data["volume"] * 0.15)           # ~1/6.5 of daily per hourly bar
        data["volume_sma_20"] = int(data["volume_sma_20"] * 0.15)
    elif timeframe == "weekly":
        # Weekly: wider bands, larger ATR, higher aggregate volume
        data["atr_14"] = round(data["atr_14"] * 2.5, 2)
        data["bb_upper"] = round(data["bb_middle"] + (data["bb_upper"] - data["bb_middle"]) * 1.8, 2)
        data["bb_lower"] = round(data["bb_middle"] - (data["bb_middle"] - data["bb_lower"]) * 1.8, 2)
        data["volume"] = int(data["volume"] * 5)
        data["volume_sma_20"] = int(data["volume_sma_20"] * 5)

    return data


def _mock_price_history(symbol: str) -> pd.DataFrame:
    """Generate synthetic 6-month OHLCV data for chart display."""
    data = MOCK_INDICATORS.get(symbol, MOCK_INDICATORS["AAPL"])
    base_price = data["current_price"]
    n_days = 130
    dates = pd.bdate_range(end=date.today(), periods=n_days)
    np.random.seed(hash(symbol) % 2**31)
    returns = np.random.normal(0.0003, 0.015, n_days)
    prices = base_price * np.exp(np.cumsum(returns) - np.cumsum(returns)[-1])
    # Make the last price match current_price
    prices = prices * (base_price / prices[-1])
    df = pd.DataFrame({
        "Open": prices * (1 + np.random.uniform(-0.005, 0.005, n_days)),
        "High": prices * (1 + np.random.uniform(0.002, 0.02, n_days)),
        "Low": prices * (1 - np.random.uniform(0.002, 0.02, n_days)),
        "Close": prices,
        "Volume": np.random.randint(10_000_000, 80_000_000, n_days),
    }, index=dates)
    return df


def _mock_fetch(symbol: str, timeframe: str = "daily") -> dict:
    """Build the same {indicators, regime} dict as the live fetch."""
    ind_data = _mock_indicators(symbol, timeframe)
    ind = MarketIndicators(**ind_data)
    analyzer = MarketAnalyzer()
    regime = analyzer.classify_regime(ind)
    return {"indicators": ind.model_dump(), "regime": regime.value}


# ── Live data fetchers ────────────────────────────────────────────

@st.cache_data(ttl=300, show_spinner="Fetching market data…")
def fetch_indicators(symbol: str, timeframe: str = "daily") -> dict:
    """Fetch live market indicators via the MarketAnalyzer (cached 5 min)."""
    analyzer = MarketAnalyzer()
    ind = analyzer.analyze(symbol, timeframe=timeframe)
    regime = analyzer.classify_regime(ind)
    return {"indicators": ind.model_dump(), "regime": regime.value}


@st.cache_data(ttl=300, show_spinner="Downloading price history…")
def fetch_price_history(symbol: str, period: str = "6mo") -> pd.DataFrame:
    df = yf.download(symbol, period=period, interval="1d", progress=False)
    if isinstance(df.columns, pd.MultiIndex):
        df.columns = df.columns.get_level_values(0)
    return df


def build_simulated_portfolio(
    symbol: str,
    shares: int,
    avg_cost: float,
    current_price: float,
    portfolio_value: float,
    cash: float,
) -> PortfolioSummary:
    """Build a PortfolioSummary from user inputs."""
    mv = shares * current_price
    return PortfolioSummary(
        account=AccountInfo(
            account_id="SIM",
            buying_power=cash,
            cash=cash,
            portfolio_value=portfolio_value,
            options_buying_power=cash * 0.5,
        ),
        stock_positions=[
            StockPosition(
                symbol=symbol.upper(),
                quantity=float(shares),
                average_cost=avg_cost,
                current_price=current_price,
                market_value=mv,
                unrealized_pnl=(current_price - avg_cost) * shares,
            )
        ]
        if shares > 0
        else [],
        total_options_allocation=0.0,
        daily_pnl=0.0,
        trades_today=0,
    )


def generate_simulated_chain(
    symbol: str, current_price: float, vix: float, dte: int = 37
) -> list[OptionContract]:
    """Generate a synthetic options chain for simulation purposes.
    
    NOTE: These are Black-Scholes estimates, NOT real market prices.
    Real prices may differ significantly, especially for 0DTE options
    where time value is near zero. Use live chain fetch when available.
    """
    contracts: list[OptionContract] = []
    exp = date.today() + timedelta(days=dte)  # actual expiration date (0DTE = today)
    actual_dte = max(dte, 1)  # min 1 day for pricing math to avoid div-by-zero
    iv_base = max(0.15, vix / 100 + 0.05)

    strike_step = 5.0 if current_price > 100 else 2.5 if current_price > 50 else 1.0
    low_strike = math.floor((current_price * 0.85) / strike_step) * strike_step
    high_strike = math.ceil((current_price * 1.15) / strike_step) * strike_step

    strike = low_strike
    while strike <= high_strike:
        for opt_type in ("call", "put"):
            moneyness = (strike - current_price) / current_price
            iv = iv_base + abs(moneyness) * 0.1  # simple smile

            T = actual_dte / 365
            d1 = (math.log(current_price / strike) + (0.04 + 0.5 * iv**2) * T) / (
                iv * math.sqrt(T)
            )
            from scipy.stats import norm

            nd1 = norm.cdf(d1)
            delta = nd1 if opt_type == "call" else nd1 - 1
            gamma = norm.pdf(d1) / (current_price * iv * math.sqrt(T))
            theta = -(current_price * norm.pdf(d1) * iv) / (2 * math.sqrt(T)) / 365
            vega_val = current_price * norm.pdf(d1) * math.sqrt(T) / 100

            if opt_type == "call":
                intrinsic = max(0, current_price - strike)
            else:
                intrinsic = max(0, strike - current_price)
            time_val = max(0.05, iv * current_price * math.sqrt(T) * 0.4)
            mid = round(intrinsic + time_val, 2)
            bid = round(mid * 0.95, 2)
            ask = round(mid * 1.05, 2)

            sym = f"{symbol}{exp.strftime('%y%m%d')}{'C' if opt_type == 'call' else 'P'}{int(strike * 1000):08d}"
            contracts.append(
                OptionContract(
                    symbol=sym,
                    underlying=symbol,
                    strike=strike,
                    expiration=exp,
                    option_type=opt_type,
                    bid=bid,
                    ask=ask,
                    mid=mid,
                    last=mid,
                    volume=int(np.random.randint(100, 5000)),
                    open_interest=int(np.random.randint(500, 20000)),
                    greeks=Greeks(
                        delta=round(delta, 4),
                        gamma=round(gamma, 4),
                        theta=round(theta, 4),
                        vega=round(vega_val, 4),
                        implied_volatility=round(iv, 4),
                    ),
                )
            )
        strike += strike_step

    return contracts


def fetch_live_chain(
    symbol: str, current_price: float, dte: int = 0
) -> list[OptionContract] | None:
    """Fetch real options chain from Yahoo Finance via yfinance.
    
    No login required — uses free public market data.
    Returns None if no data available — caller should fall back to
    generate_simulated_chain().
    """
    try:
        ticker = yf.Ticker(symbol)
        expirations = ticker.options
        if not expirations:
            return None

        target_date = date.today() + timedelta(days=dte)
        target_str = target_date.strftime("%Y-%m-%d")

        # Find the closest expiration to the target DTE
        best_exp = min(expirations, key=lambda e: abs((datetime.strptime(e, "%Y-%m-%d").date() - target_date).days))
        exp_date = datetime.strptime(best_exp, "%Y-%m-%d").date()

        chain_data = ticker.option_chain(best_exp)
        contracts: list[OptionContract] = []

        for opt_type, df in [("call", chain_data.calls), ("put", chain_data.puts)]:
            for _, row in df.iterrows():
                strike = float(row.get("strike", 0))
                if strike == 0:
                    continue
                # Only include strikes within ~15% of current price
                if abs(strike - current_price) / current_price > 0.15:
                    continue

                bid = float(row.get("bid", 0) or 0)
                ask = float(row.get("ask", 0) or 0)
                last = float(row.get("lastPrice", 0) or 0)
                # Guard against NaN in all numeric fields
                if math.isnan(bid): bid = 0.0
                if math.isnan(ask): ask = 0.0
                if math.isnan(last): last = 0.0
                mid = round((bid + ask) / 2, 2) if (bid + ask) > 0 else last
                iv = float(row.get("impliedVolatility", 0) or 0)
                if math.isnan(iv): iv = 0.0
                vol_raw = row.get("volume", 0)
                vol = int(vol_raw) if vol_raw is not None and not (isinstance(vol_raw, float) and math.isnan(vol_raw)) else 0
                oi_raw = row.get("openInterest", 0)
                oi = int(oi_raw) if oi_raw is not None and not (isinstance(oi_raw, float) and math.isnan(oi_raw)) else 0
                contract_sym = str(row.get("contractSymbol", ""))

                # yfinance doesn't provide greeks directly — estimate delta from IV
                # Simple Black-Scholes delta approximation
                T = max((exp_date - date.today()).days, 1) / 365
                try:
                    from scipy.stats import norm
                    d1 = (math.log(current_price / strike) + (0.04 + 0.5 * iv**2) * T) / (iv * math.sqrt(T)) if iv > 0 and T > 0 else 0
                    delta = round(norm.cdf(d1) if opt_type == "call" else norm.cdf(d1) - 1, 4)
                    gamma = round(norm.pdf(d1) / (current_price * iv * math.sqrt(T)), 4) if iv > 0 else 0.0
                    theta = round(-(current_price * norm.pdf(d1) * iv) / (2 * math.sqrt(T)) / 365, 4) if iv > 0 else 0.0
                    vega_val = round(current_price * norm.pdf(d1) * math.sqrt(T) / 100, 4) if iv > 0 else 0.0
                except Exception:
                    delta, gamma, theta, vega_val = 0.5 if opt_type == "call" else -0.5, 0.0, 0.0, 0.0

                contracts.append(
                    OptionContract(
                        symbol=contract_sym or f"{symbol}{exp_date.strftime('%y%m%d')}{'C' if opt_type == 'call' else 'P'}{int(strike * 1000):08d}",
                        underlying=symbol,
                        strike=strike,
                        expiration=exp_date,
                        option_type=opt_type,
                        bid=bid,
                        ask=ask,
                        mid=mid,
                        last=last,
                        volume=vol,
                        open_interest=oi,
                        greeks=Greeks(
                            delta=delta,
                            gamma=gamma,
                            theta=theta,
                            vega=vega_val,
                            implied_volatility=round(iv, 4),
                        ),
                    )
                )

        if contracts:
            return contracts
        return None

    except Exception as exc:
        import logging as _log
        _log.warning("Live yfinance chain fetch failed: %s — falling back to synthetic", exc)
        return None


def build_pnl_chart(order: OptionOrder, current_price: float) -> go.Figure:
    """Build a P&L at expiration chart for the simulated order."""
    low = current_price * 0.80
    high = current_price * 1.20
    prices = np.linspace(low, high, 200)
    pnl = np.zeros_like(prices)

    for leg in order.legs:
        for i, px in enumerate(prices):
            if leg.option_type == "call":
                intrinsic = max(0, px - leg.strike)
            else:
                intrinsic = max(0, leg.strike - px)

            if "sell" in leg.action:
                pnl[i] += (order.limit_price - intrinsic) * 100 * leg.quantity if len(order.legs) == 1 else 0
            else:
                pnl[i] += (intrinsic - order.limit_price) * 100 * leg.quantity if len(order.legs) == 1 else 0

    # For multi-leg, compute properly
    if len(order.legs) > 1:
        pnl = np.zeros_like(prices)
        for leg in order.legs:
            for i, px in enumerate(prices):
                if leg.option_type == "call":
                    intrinsic = max(0, px - leg.strike)
                else:
                    intrinsic = max(0, leg.strike - px)
                sign = -1 if "sell" in leg.action else 1
                pnl[i] += sign * intrinsic * 100 * leg.quantity
        # Add/subtract net premium
        if order.limit_price:
            net_credit = order.limit_price * 100
            if any("sell" in l.action for l in order.legs):
                pnl += net_credit
            else:
                pnl -= net_credit

    fig = go.Figure()
    fig.add_trace(
        go.Scatter(
            x=prices,
            y=pnl,
            fill="tozeroy",
            fillcolor="rgba(46, 204, 113, 0.15)",
            line=dict(color="#2ecc71", width=2),
            name="P&L",
        )
    )
    fig.add_hline(y=0, line_dash="dash", line_color="gray")
    fig.add_vline(x=current_price, line_dash="dot", line_color="#3498db", annotation_text="Current")

    for leg in order.legs:
        fig.add_vline(
            x=leg.strike,
            line_dash="dot",
            line_color="#e74c3c" if "sell" in leg.action else "#2ecc71",
            annotation_text=f"{'S' if 'sell' in leg.action else 'B'} {leg.strike}",
        )

    fig.update_layout(
        title="P&L at Expiration",
        xaxis_title="Stock Price at Expiration ($)",
        yaxis_title="Profit / Loss ($)",
        template="plotly_dark",
        height=400,
        margin=dict(l=40, r=40, t=50, b=40),
    )
    return fig


def build_price_chart(df: pd.DataFrame, indicators: dict) -> go.Figure:
    """Candlestick chart with Bollinger Bands and SMAs."""
    fig = go.Figure()

    fig.add_trace(
        go.Candlestick(
            x=df.index,
            open=df["Open"],
            high=df["High"],
            low=df["Low"],
            close=df["Close"],
            name="Price",
            increasing_line_color="#2ecc71",
            decreasing_line_color="#e74c3c",
        )
    )

    # SMAs
    close = df["Close"].astype(float)
    sma20 = close.rolling(20).mean()
    sma50 = close.rolling(50).mean()

    fig.add_trace(go.Scatter(x=df.index, y=sma20, name="SMA 20", line=dict(color="#3498db", width=1)))
    fig.add_trace(go.Scatter(x=df.index, y=sma50, name="SMA 50", line=dict(color="#f39c12", width=1)))

    # Bollinger
    bb_mid = sma20
    bb_std = close.rolling(20).std()
    bb_upper = bb_mid + 2 * bb_std
    bb_lower = bb_mid - 2 * bb_std
    fig.add_trace(
        go.Scatter(x=df.index, y=bb_upper, name="BB Upper", line=dict(color="rgba(149,165,166,0.4)", dash="dash", width=1))
    )
    fig.add_trace(
        go.Scatter(x=df.index, y=bb_lower, name="BB Lower", line=dict(color="rgba(149,165,166,0.4)", dash="dash", width=1),
                   fill="tonexty", fillcolor="rgba(149,165,166,0.05)")
    )

    fig.update_layout(
        title=f"{indicators.get('symbol', '')} — Price & Indicators",
        xaxis_rangeslider_visible=False,
        template="plotly_dark",
        height=450,
        margin=dict(l=40, r=40, t=50, b=40),
    )
    return fig


# ═════════════════════════════════════════════════════════════���════
#  SIDEBAR
# ══════════════════════════════════════════════════════════════════

st.sidebar.image("https://img.icons8.com/3d-fluency/94/money-bag.png", width=60)
st.sidebar.title("Options Agent Simulator")
st.sidebar.markdown("---")

# ── Data Mode toggle ──
mock_mode = st.sidebar.toggle(
    "🧪 Mock Mode (offline)",
    value=True,
    help="Use bundled sample data instead of live Yahoo Finance. No internet needed.",
)
if mock_mode:
    st.sidebar.caption("📦 Using mock data — AAPL, SPY, TSLA, MSFT available")

symbol = st.sidebar.text_input("Stock Symbol", value="AAPL", max_chars=10).upper().strip()

st.sidebar.markdown("### 🕐 Analysis Timeframe")
timeframe = st.sidebar.select_slider(
    "Timeframe",
    options=["15min", "1hour", "daily", "weekly"],
    value="daily",
    format_func=lambda x: {
        "15min": "⚡ 15-Min (Intraday)",
        "1hour": "🕐 1-Hour (Intraday)",
        "daily": "📅 Daily (Swing)",
        "weekly": "📆 Weekly (Position)",
    }[x],
)
TIMEFRAME_DESCRIPTIONS = {
    "15min": "Scalping / day-trading entries — very short-term signals",
    "1hour": "Intraday swing entries — short-term signals for 0–7 DTE",
    "daily": "Swing / position entries — standard for 14–60 DTE options",
    "weekly": "Long-term position entries — ideal for 60–365 DTE LEAPS",
}
st.sidebar.caption(f"📊 {TIMEFRAME_DESCRIPTIONS[timeframe]}")

# Hardcoded portfolio defaults (not shown in UI — only used internally for eligibility)
portfolio_value = 100_000
cash = 50_000
shares = 0
avg_cost = 0.01

st.sidebar.markdown("### ⚙️ Risk Parameters")
max_pos_pct = st.sidebar.slider("Max Position Size (%)", 1, 20, 5) / 100
max_loss_pct = st.sidebar.slider("Max Loss per Trade (%)", 1, 10, 2) / 100
min_dte = st.sidebar.slider("Min Days to Expiration", 0, 365, 0)
max_dte = st.sidebar.slider("Max Days to Expiration", 0, 365, 45)

if max_dte < min_dte:
    st.sidebar.warning("⚠️ Max DTE must be ≥ Min DTE. Using Min DTE as Max.")
    max_dte = min_dte

st.sidebar.markdown("### 🎯 Strategy Selection")
strategy_mode = st.sidebar.radio(
    "Strategy mode",
    options=["auto", "manual"],
    format_func=lambda x: "🤖 Auto (regime-based)" if x == "auto" else "🎛️ Manual (choose your own)",
    horizontal=True,
)

manual_strategy = None
if strategy_mode == "manual":
    manual_strategy = st.sidebar.selectbox(
        "Select strategy",
        options=["buy_call", "buy_put"],
        format_func=lambda x: f"{STRATEGY_DESCRIPTIONS[x]['icon']}  {STRATEGY_DESCRIPTIONS[x]['name']}",
    )

st.sidebar.markdown("---")
analyze_btn = st.sidebar.button("🔍  Analyze & Simulate", type="primary", use_container_width=True)


# ══════════════════════════════════════════════════════════════════
#  MAIN PAGE
# ══════════════════════════════════════════════════════════════════

st.title("📈 Options Trading Agent — Simulation Dashboard")
st.caption("Analyze market conditions, view strategy recommendations, and simulate trades — no real orders.")

if not analyze_btn and "result" not in st.session_state:
    st.info("👈 Enter a symbol and click **Analyze & Simulate** to get started.")
    st.stop()

# ── Run analysis ─────────────────────────────────────────────────

if analyze_btn:
    with st.spinner(f"{'Loading mock data' if mock_mode else 'Analyzing'} {symbol} ({timeframe})…"):
        try:
            if mock_mode:
                raw = _mock_fetch(symbol, timeframe)
                hist = _mock_price_history(symbol)
            else:
                raw = fetch_indicators(symbol, timeframe)
                hist = fetch_price_history(symbol)
            st.session_state["result"] = raw
            st.session_state["hist"] = hist
            st.session_state["symbol"] = symbol
            st.session_state["portfolio_cfg"] = {
                "portfolio_value": portfolio_value,
                "cash": cash,
                "shares": shares,
                "avg_cost": avg_cost,
            }
            st.session_state["risk_cfg"] = {
                "max_pos_pct": max_pos_pct,
                "max_loss_pct": max_loss_pct,
                "min_dte": min_dte,
                "max_dte": max_dte,
            }
            st.session_state["strategy_mode"] = strategy_mode
            st.session_state["manual_strategy"] = manual_strategy
            st.session_state["timeframe"] = timeframe
        except Exception as exc:
            st.error(f"Error fetching data for **{symbol}**: {exc}")
            st.stop()

# ── Retrieve from session state ──────────────────────────────────

raw = st.session_state.get("result")
hist = st.session_state.get("hist")
sym = st.session_state.get("symbol", symbol)
pcfg = st.session_state.get("portfolio_cfg", {})
rcfg = st.session_state.get("risk_cfg", {})
saved_strategy_mode = st.session_state.get("strategy_mode", "auto")
saved_manual_strategy = st.session_state.get("manual_strategy", None)
saved_timeframe = st.session_state.get("timeframe", "daily")

if raw is None:
    st.stop()

ind_dict = raw["indicators"]
regime = MarketRegime(raw["regime"])
regime_label, regime_icon = REGIME_LABELS[regime]
regime_strategy = REGIME_STRATEGY_MAP[regime]

# ── Smart auto-selection: quality scores + opening range breakout ──
# Uses both daily indicators (6 signals) AND the 60-min opening range
# breakout direction to pick the best strategy.

indicators_for_or = MarketIndicators(**ind_dict)
_ora = OpeningRangeAnalyzer()
_or_result = _ora.analyze(indicators_for_or, mock=mock_mode)
_or_direction = _or_result.breakout_direction.value  # "bullish", "bearish", "neutral"
_or_momentum = _or_result.momentum_score  # -100 to +100
_or_confirmed = _or_result.breakout_confirmed  # |momentum| >= 40

# Recent 30-min momentum analysis
_rma = RecentMomentumAnalyzer()
_recent = _rma.analyze(indicators_for_or, mock=mock_mode)
_recent_dir = _recent.direction  # "bullish", "bearish", "neutral"
_recent_momentum = _recent.momentum_score

def _compute_quality_score(ind: dict, direction: str, or_direction: str, or_momentum: int,
                           or_confirmed: bool, recent_dir: str, recent_momentum: int) -> int:
    """Compute quality score (0-9) — delegates to shared quality_scorer."""
    return compute_quality_score(
        direction=direction,
        current_price=ind["current_price"],
        sma_20=ind["sma_20"],
        sma_50=ind["sma_50"],
        vix=ind["vix"],
        volume=ind.get("volume", 0),
        volume_sma_20=ind.get("volume_sma_20", 0),
        or_direction=or_direction,
        or_momentum=or_momentum,
        or_confirmed=or_confirmed,
        recent_dir=recent_dir,
        recent_momentum=recent_momentum,
    ).score

call_quality = _compute_quality_score(ind_dict, "buy_call", _or_direction, _or_momentum, _or_confirmed, _recent_dir, _recent_momentum)
put_quality = _compute_quality_score(ind_dict, "buy_put", _or_direction, _or_momentum, _or_confirmed, _recent_dir, _recent_momentum)

# Pick the strategy with higher quality; tie goes to regime-based pick
if call_quality > put_quality:
    auto_strategy_name = "buy_call"
elif put_quality > call_quality:
    auto_strategy_name = "buy_put"
else:
    auto_strategy_name = regime_strategy  # tie → follow regime

# Determine selected strategy: manual override or auto (quality-based)
if saved_strategy_mode == "manual" and saved_manual_strategy:
    selected_strategy_name = saved_manual_strategy
else:
    selected_strategy_name = auto_strategy_name

strat_info = STRATEGY_DESCRIPTIONS[selected_strategy_name]

# Reconstruct objects
indicators = MarketIndicators(**ind_dict)
current_price = indicators.current_price
portfolio = build_simulated_portfolio(
    sym,
    pcfg.get("shares", shares),
    pcfg.get("avg_cost", avg_cost),
    current_price,
    pcfg.get("portfolio_value", portfolio_value),
    pcfg.get("cash", cash),
)


# ══════════════════════════════════════════════════════════════════
#  SECTION 1: Market Overview
# ══════════════════════════════════════════════════════════════════

st.markdown("## 1️⃣  Market Overview")

_tf_labels = {"15min": "⚡ 15-Min", "1hour": "🕐 1-Hour", "daily": "📅 Daily", "weekly": "📆 Weekly"}
st.caption(f"Timeframe: **{_tf_labels.get(saved_timeframe, saved_timeframe)}** — All indicators computed on {saved_timeframe} bars")

cols = st.columns(6)
cols[0].metric("Price", f"${current_price:.2f}")
cols[1].metric("VIX", f"{indicators.vix:.1f}", delta=f"{'High' if indicators.vix > 25 else 'Low'}", delta_color="inverse")
cols[2].metric("RSI (14)", f"{indicators.rsi_14:.1f}", delta="Overbought" if indicators.rsi_14 > 70 else ("Oversold" if indicators.rsi_14 < 30 else "Neutral"), delta_color="off")
cols[3].metric("SMA 50", f"${indicators.sma_50:.2f}")
cols[4].metric("MACD Hist", f"{indicators.macd_histogram:.3f}", delta="Bullish" if indicators.macd_histogram > 0 else "Bearish", delta_color="normal")
cols[5].metric("ATR (14)", f"${indicators.atr_14:.2f}")

# Price chart
if hist is not None and not hist.empty:
    st.plotly_chart(build_price_chart(hist, ind_dict), use_container_width=True)

# Detailed indicator table
with st.expander("📊 All Technical Indicators", expanded=False):
    indicator_data = {
        "Indicator": [
            "Current Price", "VIX", "RSI (14)",
            "SMA 20", "SMA 50", "SMA 200",
            "Bollinger Upper", "Bollinger Middle", "Bollinger Lower",
            "MACD", "MACD Signal", "MACD Histogram",
            "ATR (14)", "Next Earnings", "Days to Earnings",
        ],
        "Value": [
            f"${current_price:.2f}",
            f"{indicators.vix:.2f}",
            f"{indicators.rsi_14:.2f}",
            f"${indicators.sma_20:.2f}",
            f"${indicators.sma_50:.2f}",
            f"${indicators.sma_200:.2f}",
            f"${indicators.bb_upper:.2f}",
            f"${indicators.bb_middle:.2f}",
            f"${indicators.bb_lower:.2f}",
            f"{indicators.macd:.4f}",
            f"{indicators.macd_signal:.4f}",
            f"{indicators.macd_histogram:.4f}",
            f"${indicators.atr_14:.2f}",
            str(indicators.next_earnings_date or "N/A"),
            str(indicators.days_to_earnings or "N/A"),
        ],
    }
    st.dataframe(pd.DataFrame(indicator_data), hide_index=True, use_container_width=True)


# ══════════════════════════════════════════════════════════════════
#  SECTION 1.5: Entry Point Analysis
# ══════════════════════════════════════════════════════════════════

st.markdown("## 🎯  Entry Point Analysis")

entry_analyzer = EntryAnalyzer()
entry = entry_analyzer.analyze(indicators, timeframe=saved_timeframe)

# Entry score gauge
ecol1, ecol2, ecol3 = st.columns([1, 2, 1])

SIGNAL_COLORS = {
    EntrySignal.STRONG_BUY: "#2ecc71",
    EntrySignal.BUY: "#3498db",
    EntrySignal.NEUTRAL: "#95a5a6",
    EntrySignal.WAIT: "#f39c12",
    EntrySignal.AVOID: "#e74c3c",
}

with ecol1:
    score_color = SIGNAL_COLORS[entry.recommendation]
    st.markdown(
        f"""
        <div style="background: linear-gradient(135deg, #1a1a2e, #16213e); border-radius: 16px;
                    padding: 24px; text-align: center; border: 2px solid {score_color};">
            <div style="font-size: 48px; font-weight: 800; color: {score_color};">{entry.composite_score}</div>
            <div style="font-size: 14px; color: #95a5a6;">/ 100</div>
            <div style="font-size: 16px; font-weight: 700; margin-top: 8px; color: {score_color};">
                {entry.recommendation.value.replace('_', ' ').upper()}
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )

with ecol2:
    st.markdown(entry.summary)
    if entry.support_level and entry.resistance_level:
        st.markdown(
            f"**Key Levels:**  "
            f"Support: **${entry.support_level:.2f}**  ·  "
            f"Resistance: **${entry.resistance_level:.2f}**  ·  "
            f"Current: **${current_price:.2f}**"
        )
    if entry.optimal_entry_price:
        st.markdown(f"💡 **Optimal entry price:** ~${entry.optimal_entry_price:.2f} (near support)")

with ecol3:
    # Mini score bar
    buy_signals = sum(1 for s in entry.signals if s.signal in (EntrySignal.STRONG_BUY, EntrySignal.BUY))
    neutral_signals = sum(1 for s in entry.signals if s.signal == EntrySignal.NEUTRAL)
    caution_signals = sum(1 for s in entry.signals if s.signal in (EntrySignal.WAIT, EntrySignal.AVOID))
    st.metric("Bullish Signals", f"{buy_signals}/{len(entry.signals)}")
    st.metric("Caution Signals", f"{caution_signals}/{len(entry.signals)}")

# Detailed signal breakdown
with st.expander("📊 Detailed Entry Signals", expanded=True):
    for sig in entry.signals:
        sig_color = SIGNAL_COLORS[sig.signal]
        score_prefix = "+" if sig.score > 0 else ""
        st.markdown(
            f"{'🟢' if sig.score > 5 else '🔵' if sig.score > 0 else '⚪' if sig.score == 0 else '🟡' if sig.score > -10 else '🔴'} "
            f"**{sig.name}** ({score_prefix}{sig.score}) — {sig.description}"
        )


# ══════════════════════════════════════════════════════════════════
#  SECTION 2: Regime Classification
# ══════════════════════════════════════════════════════════════════

st.markdown("## 2️⃣  Market Regime Classification")

rcol1, rcol2 = st.columns([1, 2])

with rcol1:
    st.markdown(
        f"""
        <div style="background: linear-gradient(135deg, #1a1a2e, #16213e); border-radius: 16px;
                    padding: 30px; text-align: center; border: 1px solid #30475e;">
            <div style="font-size: 48px;">{regime_icon}</div>
            <div style="font-size: 22px; font-weight: 700; margin-top: 8px; color: #ecf0f1;">{regime_label}</div>
            <div style="font-size: 13px; color: #95a5a6; margin-top: 4px;">{regime.value}</div>
        </div>
        """,
        unsafe_allow_html=True,
    )

with rcol2:
    st.markdown("**Classification Logic:**")
    checks = {
        "VIX Level": f"{indicators.vix:.1f} → {'🔴 High (>30)' if indicators.vix > 30 else '🟡 Elevated (20-30)' if indicators.vix >= 20 else '🟢 Low (<20)'}",
        "RSI (14)": f"{indicators.rsi_14:.1f} → {'Overbought (>70)' if indicators.rsi_14 > 70 else 'Oversold (<30)' if indicators.rsi_14 < 30 else 'Neutral (30-70)'}",
        "Trend (50 vs 200 SMA)": f"{'🔻 Death Cross' if indicators.sma_50 < indicators.sma_200 else '🔺 Golden Cross'}  (SMA50={indicators.sma_50:.0f}, SMA200={indicators.sma_200:.0f})",
        "Bollinger Position": f"Price ${current_price:.0f} {'within' if indicators.bb_lower <= current_price <= indicators.bb_upper else 'outside'} bands (${indicators.bb_lower:.0f}–${indicators.bb_upper:.0f})",
        "MACD Momentum": f"{'📈 Positive' if indicators.macd_histogram > 0 else '📉 Negative'} (histogram={indicators.macd_histogram:.3f})",
    }
    for k, v in checks.items():
        st.markdown(f"- **{k}:** {v}")


# ══════════════════════════════════════════════════════════════════
#  SECTION 3: Strategy Recommendation
# ══════════════════════════════════════════════════════════════════

st.markdown("## 3️⃣  Strategy Selection")

if saved_strategy_mode == "manual":
    st.info(
        f"🎛️ **Manual mode** — You selected **{STRATEGY_DESCRIPTIONS[selected_strategy_name]['icon']} "
        f"{STRATEGY_DESCRIPTIONS[selected_strategy_name]['name']}**.  "
        f"(Auto pick: {STRATEGY_DESCRIPTIONS[auto_strategy_name]['icon']} "
        f"{STRATEGY_DESCRIPTIONS[auto_strategy_name]['name']} — "
        f"Call quality {call_quality}/9, Put quality {put_quality}/9)"
    )
else:
    call_label = "🟢" if call_quality >= 6 else "🔵" if call_quality >= 3 else "🟡"
    put_label = "🟢" if put_quality >= 6 else "🔵" if put_quality >= 3 else "🟡"
    or_emoji = "🟢" if _or_direction == "bullish" else "🔴" if _or_direction == "bearish" else "⚪"
    rc_emoji = "🟢" if _recent_dir == "bullish" else "🔴" if _recent_dir == "bearish" else "⚪"
    st.info(
        f"🤖 **Auto mode** — Selected **{STRATEGY_DESCRIPTIONS[selected_strategy_name]['icon']} "
        f"{STRATEGY_DESCRIPTIONS[selected_strategy_name]['name']}** based on signal quality.  \n"
        f"🚀 Buy Call: {call_label} **{call_quality}/9** &nbsp;|&nbsp; "
        f"💥 Buy Put: {put_label} **{put_quality}/9**  \n"
        f"{or_emoji} 60-min opening range: **{_or_direction.upper()}** ({_or_momentum:+d}) &nbsp;|&nbsp; "
        f"{rc_emoji} Recent 30-min: **{_recent_dir.upper()}** ({_recent_momentum:+d})"
    )

scol1, scol2 = st.columns(2)
for col, (sname, sinfo) in zip([scol1, scol2], STRATEGY_DESCRIPTIONS.items()):
    is_selected = sname == selected_strategy_name
    is_auto_pick = sname == auto_strategy_name
    border_color = sinfo["color"] if is_selected else "#30475e"
    bg = f"rgba({int(sinfo['color'][1:3],16)},{int(sinfo['color'][3:5],16)},{int(sinfo['color'][5:7],16)},0.08)" if is_selected else "transparent"
    if is_selected:
        badge = "✅ SELECTED"
    elif is_auto_pick and saved_strategy_mode == "manual":
        badge = "🤖 AUTO PICK"
    else:
        badge = ""
    with col:
        st.markdown(
            f"""
            <div style="border: 2px solid {border_color}; border-radius: 12px; padding: 20px;
                        background: {bg}; min-height: 180px;">
                <div style="font-size: 32px;">{sinfo['icon']}</div>
                <div style="font-size: 17px; font-weight: 700; margin-top: 6px;">{sinfo['name']}</div>
                <div style="font-size: 12px; color: #95a5a6; margin-top: 6px;">{sinfo['desc']}</div>
                <div style="font-size: 13px; color: {sinfo['color']}; font-weight: 700; margin-top: 10px;">{badge}</div>
            </div>
            """,
            unsafe_allow_html=True,
        )


# ══════════════════════════════════════════════════════════════════
#  SECTION 4: Simulated Order Construction
# ══════════════════════════════════════════════════════════════════

st.markdown("## 4️⃣  Simulated Trade")

ALL_STRATEGY_KEYS = ["buy_call", "buy_put"]

# Allow user to override strategy
override_strategy = st.selectbox(
    "Strategy to simulate (change to try a different one):",
    options=ALL_STRATEGY_KEYS,
    index=ALL_STRATEGY_KEYS.index(
        selected_strategy_name if selected_strategy_name in ALL_STRATEGY_KEYS
        else "buy_call"
    ),
    format_func=lambda x: f"{STRATEGY_DESCRIPTIONS[x]['icon']}  {STRATEGY_DESCRIPTIONS[x]['name']}",
)

strategy_map = {
    "buy_call": BuyCallStrategy(),
    "buy_put": BuyPutStrategy(),
}
chosen_strategy = strategy_map[override_strategy]
chosen_regime_map = {
    "buy_call": MarketRegime.LOW_VOL_BULLISH,
    "buy_put": MarketRegime.HIGH_VOL_BEARISH,
}

# Eligibility check — use the actual detected regime for buy_call/buy_put
# so the "oversold bounce" / "overbought reversal" paths can trigger
if override_strategy in ("buy_call", "buy_put"):
    eligibility_regime = regime  # use the real market regime
else:
    eligibility_regime = chosen_regime_map[override_strategy]

eligible = chosen_strategy.evaluate_eligibility(
    eligibility_regime, portfolio, indicators
)

if not eligible:
    # Build strategy-specific reason
    if override_strategy == "buy_call":
        specific_reasons = (
            f"- RSI is {indicators.rsi_14:.1f} — Buy Call is blocked when RSI > 80 (overextended)\n"
            f"- Market regime is **{regime_label}** — Buy Call is blocked in bearish regimes unless RSI < 30 (oversold bounce)"
        )
    elif override_strategy == "buy_put":
        specific_reasons = (
            f"- RSI is {indicators.rsi_14:.1f} — Buy Put is blocked when RSI < 20 (extremely oversold, bounce likely)\n"
            f"- Market regime is **{regime_label}** — Buy Put is blocked in bullish regimes unless RSI > 70 (overbought reversal)"
        )
    else:
        specific_reasons = (
            f"- RSI is {indicators.rsi_14:.1f}\n"
            f"- Market regime is **{regime_label}**"
        )
    st.warning(
        f"⚠️ **{STRATEGY_DESCRIPTIONS[override_strategy]['name']}** is not eligible with your current simulated portfolio.\n\n"
        f"**Possible reasons:**\n{specific_reasons}\n\n"
        f"Adjust your portfolio in the sidebar and re-run."
    )
else:
    # Generate chain & order — use DTE range from sidebar
    is_scalp_strategy = override_strategy in ("buy_call", "buy_put")
    if is_scalp_strategy:
        dte_min = rcfg.get("min_dte", min_dte)
        dte_max = min(rcfg.get("max_dte", max_dte), 7)  # cap scalps at 7 DTE

        # Try live Robinhood chain first (when not in mock mode)
        chain = None
        live_chain_used = False
        if not mock_mode:
            for dte_val in range(dte_min, dte_max + 1):
                live = fetch_live_chain(sym, current_price, dte=dte_val)
                if live:
                    chain = live if chain is None else chain + live
                    live_chain_used = True

        # Fall back to synthetic chain
        if not chain:
            chain = []
            for dte_val in range(dte_min, dte_max + 1):
                chain.extend(generate_simulated_chain(sym, current_price, indicators.vix, dte=dte_val))
    else:
        chain = generate_simulated_chain(sym, current_price, indicators.vix, dte=(rcfg.get("min_dte", min_dte) + rcfg.get("max_dte", max_dte)) // 2)
        live_chain_used = False
    try:
        order = chosen_strategy.construct_order(sym, chain, portfolio, indicators)

        # Display order legs
        st.markdown(f"### {STRATEGY_DESCRIPTIONS[override_strategy]['icon']}  Order Details")

        # Show chain data source
        if is_scalp_strategy:
            if live_chain_used:
                st.success("📡 **Live options data** — real bid/ask prices from Yahoo Finance (no login required)")
            else:
                st.warning(
                    "⚠️ **Synthetic options data** — prices are Black-Scholes estimates, NOT real market prices. "
                    "Real prices may differ significantly (especially 0DTE). "
                    "Turn off Mock Mode to fetch live options chain from Yahoo Finance."
                )

        leg_rows = []
        for leg in order.legs:
            leg_rows.append({
                "Action": leg.action.replace("_", " ").title(),
                "Type": leg.option_type.upper(),
                "Strike": f"${leg.strike:.2f}",
                "Expiration": str(leg.expiration),
                "DTE": (leg.expiration - date.today()).days,
                "Qty": leg.quantity,
            })
        st.dataframe(pd.DataFrame(leg_rows), hide_index=True, use_container_width=True)

        # Key metrics
        mcol1, mcol2, mcol3, mcol4 = st.columns(4)
        mcol1.metric("Max Profit", f"${order.max_profit:,.2f}", delta="", delta_color="off")
        mcol2.metric("Max Loss", f"${order.max_loss:,.2f}", delta="", delta_color="off")
        mcol3.metric("Risk/Reward", f"{order.risk_reward_ratio:.3f}")
        mcol4.metric("Limit Price", f"${order.limit_price:.2f}" if order.limit_price else "Market")

        # ── Entry Status Alert (for breakout strategies) ──
        if order.breakout_price is not None and override_strategy in ("buy_call", "buy_put"):
            bp = order.breakout_price
            if override_strategy == "buy_call":
                triggered = current_price > bp
                distance = bp - current_price
                direction_word = "above"
            else:
                triggered = current_price < bp
                distance = current_price - bp
                direction_word = "below"

            if triggered:
                st.success(
                    f"🟢 **BREAKOUT TRIGGERED** — {sym} is ${current_price:.2f}, "
                    f"already {direction_word} the ${bp:.2f} trigger. Entry conditions met!"
                )
            else:
                st.error(
                    f"⏳ **WAIT — BREAKOUT NOT YET TRIGGERED**\n\n"
                    f"**Do NOT buy this option yet.** {sym} is **${current_price:.2f}**, "
                    f"still **${abs(distance):.2f} away** from the breakout trigger of **${bp:.2f}**.\n\n"
                    f"- Set an **alert** for {sym} {'>' if override_strategy == 'buy_call' else '<'} ${bp:.2f}\n"
                    f"- Only enter when price breaks {direction_word} ${bp:.2f}\n"
                    f"- If it never breaks out today → **skip this trade**"
                )

        # ── Rationale (formatted) ──
        _rationale_raw = order.rationale or ""
        # Split on sentence boundaries (". ") to get individual points
        _rationale_parts = [p.strip() for p in _rationale_raw.split(". ") if p.strip()]

        with st.expander("💡 **Trade Rationale**", expanded=True):
            for part in _rationale_parts:
                part_clean = part.rstrip(".")
                if part_clean.startswith("✅"):
                    st.markdown(f"&nbsp;&nbsp;&nbsp;&nbsp;{part_clean}")
                elif part_clean.startswith("⚠️") or part_clean.startswith("📈") or part_clean.startswith("📉"):
                    st.markdown(f"&nbsp;&nbsp;&nbsp;&nbsp;{part_clean}")
                elif part_clean.startswith("Buy "):
                    st.markdown(f"**📋 {part_clean}.**")
                elif part_clean.startswith("Breakout") or part_clean.startswith("Breakdown"):
                    st.markdown(f"**🎯 {part_clean}.**")
                elif part_clean.startswith("Range:"):
                    st.markdown(f"**📐 {part_clean}.**")
                elif part_clean.startswith("Stop:"):
                    st.markdown(f"**🛑 {part_clean}.**")
                elif part_clean.startswith("Quality:"):
                    st.markdown(f"**⭐ {part_clean}.**")
                elif part_clean.startswith("Exit:"):
                    st.markdown(f"**🚪 {part_clean}.**")
                elif "backtest" in part_clean.lower() or "optimized" in part_clean.lower():
                    st.caption(f"📊 {part_clean}.")
                else:
                    st.markdown(f"- {part_clean}.")

        # ── Breakout Levels (buy_call / buy_put) ──
        if order.breakout_price is not None and override_strategy in ("buy_call", "buy_put"):
            st.markdown("### 🎯 Exact Breakout Levels")

            dir_color = "#00d2ff" if order.breakout_direction == "bullish" else "#ff6b6b" if order.breakout_direction == "bearish" else "#95a5a6"
            dir_emoji = "🟢" if order.breakout_direction == "bullish" else "🔴" if order.breakout_direction == "bearish" else "⚪"
            trigger_word = "above" if override_strategy == "buy_call" else "below"

            st.markdown(
                f"""
                <div style="background: linear-gradient(135deg, #1a1a2e, #16213e); border-radius: 12px;
                            padding: 16px; border: 2px solid {dir_color}; margin-bottom: 16px;">
                    <div style="font-size: 18px; font-weight: 700; color: {dir_color};">
                        {dir_emoji} BREAKOUT TRIGGER: Stock breaks {trigger_word} <span style="font-size: 22px;">${order.breakout_price:.2f}</span>
                    </div>
                    <div style="font-size: 13px; color: #95a5a6; margin-top: 4px;">
                        Active Range: ${order.opening_range_low:.2f} – ${order.opening_range_high:.2f} (from recent 30-min window)
                    </div>
                </div>
                """,
                unsafe_allow_html=True,
            )

            bp1, bp2, bp3, bp4, bp5, bp6 = st.columns(6)
            bp1.metric("📍 Entry Price", f"${order.entry_price:.2f}",
                       delta=f"{'Above' if override_strategy == 'buy_call' else 'Below'} range", delta_color="off")
            bp2.metric("🛑 Stop Loss", f"${order.stop_loss_price:.2f}",
                       delta=f"Range midpoint", delta_color="inverse")
            bp3.metric("🎯 T1 (0.75R)", f"${order.profit_target_1:.2f}",
                       delta=f"+${abs(order.profit_target_1 - order.entry_price):.2f}", delta_color="normal")
            bp4.metric("🎯 T2 (1.5R)", f"${order.profit_target_2:.2f}",
                       delta=f"+${abs(order.profit_target_2 - order.entry_price):.2f}", delta_color="normal")
            bp5.metric("⏰ Time Stop", "3:00 PM ET",
                       delta="Close all", delta_color="off")
            bp6.metric("Direction", f"{order.breakout_direction.upper()}")

            # Step-by-step execution
            with st.expander("📋 How to Execute This Breakout Trade", expanded=True):
                if override_strategy == "buy_call":
                    st.markdown(f"""
**1. Wait for the 60-min opening range** (9:30–10:30 AM ET)
   - Range High: **${order.opening_range_high:.2f}** | Range Low: **${order.opening_range_low:.2f}**

**2. Entry trigger:** Stock price breaks **above ${order.breakout_price:.2f}**
   - ✅ Confirm price is **above VWAP** (strongest backtest signal — 57% win rate)
   - ✅ Confirm 60-min candle closed **near highs** (2nd strongest signal — 56% win rate)
   - Buy the **${order.legs[0].strike:.0f} CALL** expiring **{order.legs[0].expiration}** at ~**${order.limit_price:.2f}**

**3. Stop loss:** **${order.stop_loss_price:.2f}** (range midpoint — tighter than range low)
   - Backtest-optimized: tighter stop cuts losers faster (only 10-13% stop rate)

**4. Take profit (scaled exit):**
   - **Target 1 (0.75R):** Close HALF at stock price **${order.profit_target_1:.2f}** → then trail stop to breakeven
   - **Target 2 (1.5R):** Close remainder at **${order.profit_target_2:.2f}**
   - *(Backtest: T1 hits 20-43% of trades; old T2 at 2R never hit)*

**5. ⏰ Time stop: Close ALL by 3:00 PM ET**
   - Backtest finding: 70% of EOD exits are losers — don't hold hoping for a late move

**6. Backtest stats (SPY 30d):** 50% call win rate, 1.97 profit factor, avg winner $3.74
""")
                else:  # buy_put
                    st.markdown(f"""
**1. Wait for the 60-min opening range** (9:30–10:30 AM ET)
   - Range High: **${order.opening_range_high:.2f}** | Range Low: **${order.opening_range_low:.2f}**

**2. Entry trigger:** Stock price breaks **below ${order.breakout_price:.2f}**
   - ✅ Confirm price is **below VWAP** (strongest backtest signal)
   - ✅ Confirm 60-min candle closed **near lows** (2nd strongest signal)
   - Buy the **${order.legs[0].strike:.0f} PUT** expiring **{order.legs[0].expiration}** at ~**${order.limit_price:.2f}**

**3. Stop loss:** **${order.stop_loss_price:.2f}** (range midpoint — tighter than range high)
   - Backtest-optimized: tighter stop cuts losers faster

**4. Take profit (scaled exit):**
   - **Target 1 (0.75R):** Close HALF at stock price **${order.profit_target_1:.2f}** → then trail stop to breakeven
   - **Target 2 (1.5R):** Close remainder at **${order.profit_target_2:.2f}**

**5. ⏰ Time stop: Close ALL by 3:00 PM ET**
   - Backtest finding: 70% of EOD exits are losers

**6. Backtest stats (SPY 30d):** 63.6% put win rate (BEST direction), 1.97 profit factor
""")


        # ── Opening Range Analysis (Buy Call / Buy Put) ──
        if override_strategy in ("buy_call", "buy_put"):
            st.markdown("### ⚡ 60-Minute Opening Range Analysis")

            ora = OpeningRangeAnalyzer()
            orng = ora.analyze(indicators, mock=mock_mode)

            # Show data source badge
            if orng.data_source == "live_intraday":
                st.success(f"📡 **Live data** — computed from {orng.opening_range_bars} actual 5-min candles (9:30–10:30 ET)")
            else:
                st.info("📊 **Estimated** — synthesized from daily indicators. Turn off Mock Mode for live 5-min candle data.")

            st.markdown(orng.summary)

            # Key levels
            or1, or2, or3, or4 = st.columns(4)
            dir_color = "#00d2ff" if orng.breakout_direction == BreakoutDirection.BULLISH else "#ff6b6b" if orng.breakout_direction == BreakoutDirection.BEARISH else "#95a5a6"
            or1.metric("Range High", f"${orng.range_high:.2f}")
            or2.metric("Range Low", f"${orng.range_low:.2f}")
            or3.metric("Range Width", f"${orng.range_width:.2f}", delta=f"{orng.range_width_pct:.2f}%", delta_color="off")
            or4.metric("Momentum", f"{orng.momentum_score:+d}/100", delta=orng.breakout_direction.value.upper(), delta_color="normal" if orng.momentum_score > 0 else "inverse")

            # Entry / Exit levels
            st.markdown("#### 🎯 Scalp Levels")
            lv1, lv2, lv3, lv4, lv5 = st.columns(5)
            lv1.metric("Entry", f"${orng.entry_price:.2f}")
            lv2.metric("Stop Loss", f"${orng.stop_loss:.2f}", delta=f"-${orng.risk_per_share:.2f} risk", delta_color="inverse")
            lv3.metric("Target 1 (1:1)", f"${orng.target_1:.2f}", delta=f"+${orng.risk_per_share:.2f}", delta_color="normal")
            lv4.metric("Target 2 (2:1)", f"${orng.target_2:.2f}", delta=f"+${orng.risk_per_share * 2:.2f}", delta_color="normal")
            lv5.metric("Risk/Share", f"${orng.risk_per_share:.2f}")

            # Signals breakdown
            with st.expander("📊 Opening Range Signals", expanded=True):
                for sig in orng.signals:
                    s = sig["score"]
                    icon = "🟢" if s > 10 else "🔵" if s > 0 else "⚪" if s == 0 else "🟡" if s > -10 else "🔴"
                    st.markdown(f"{icon} **{sig['name']}** ({'+' if s > 0 else ''}{s}) — {sig['desc']}")

            if not orng.breakout_confirmed:
                st.warning("⏳ Breakout not yet confirmed. Wait for price to break the opening range with momentum before entering.")

            # ── Recent 30-Min Momentum Analysis ──
            st.markdown("### 🕐 Recent 30-Minute Momentum")

            if _recent.data_source == "live":
                st.success(f"📡 **Live data** — {_recent.candle_count} actual 5-min candles")
            else:
                st.info("📊 **Estimated** — synthesized from daily indicators. Turn off Mock Mode for live data.")

            st.markdown(_recent.summary)

            rm1, rm2, rm3, rm4 = st.columns(4)
            rc_color = "#00d2ff" if _recent.direction == "bullish" else "#ff6b6b" if _recent.direction == "bearish" else "#95a5a6"
            rm1.metric("Direction", _recent.direction.upper())
            rm2.metric("Momentum", f"{_recent.momentum_score:+d}/100")
            rm3.metric("30-min Change", f"{_recent.price_change_pct:+.2f}%")
            rm4.metric("5-min RSI", f"{_recent.rsi_5min:.1f}")

            with st.expander("📊 Recent 30-Min Signals", expanded=False):
                for sig in _recent.signals:
                    s = sig["score"]
                    icon = "🟢" if s > 10 else "🔵" if s > 0 else "⚪" if s == 0 else "🟡" if s > -10 else "🔴"
                    st.markdown(f"{icon} **{sig['name']}** ({'+' if s > 0 else ''}{s}) — {sig['desc']}")

        # P&L chart
        st.plotly_chart(build_pnl_chart(order, current_price), use_container_width=True)

        # ══════════════════════════════════════════════════════════
        #  SECTION 4.5: Exact Trade Execution Guide
        # ══════════════════════════════════════════════════════════

        st.markdown("## 🎯  Exact Trade Execution Guide")

        guide = build_execution_guide(order, indicators, timeframe=saved_timeframe)

        # Notes / overall readiness
        for note in guide.notes:
            st.markdown(note)

        # ── 4.5a: Contract Details ──
        with st.expander("📋 Exact Contracts to Trade", expanded=True):
            st.dataframe(pd.DataFrame(guide.contract_legs), hide_index=True, use_container_width=True)
            if order.limit_price:
                st.markdown(f"**Net Limit Price:** **${order.limit_price:.2f}** per contract")
            st.markdown(f"**Max Profit:** ${order.max_profit:,.2f}  ·  **Max Loss:** ${order.max_loss:,.2f}  ·  **Risk/Reward:** {order.risk_reward_ratio:.3f}")

        # ── 4.5b: Step-by-Step Brokerage Instructions ──
        with st.expander("🏦 Step-by-Step Brokerage Instructions", expanded=True):
            for step in guide.brokerage_steps:
                st.markdown(step)
            if mock_mode:
                st.caption("⚠️ Mock mode — contract symbols are synthetic. Use real chain data in live mode.")

        # ── 4.5c: Optimal Entry Conditions ──
        with st.expander("📊 Optimal Entry Conditions (Live Check)", expanded=True):
            cond_cols = st.columns([3, 2, 2, 1])
            cond_cols[0].markdown("**Condition**")
            cond_cols[1].markdown("**Current**")
            cond_cols[2].markdown("**Ideal Range**")
            cond_cols[3].markdown("**Status**")

            for cond in guide.entry_conditions:
                c1, c2, c3, c4 = st.columns([3, 2, 2, 1])
                c1.markdown(f"**{cond.name}**")
                c2.markdown(cond.current_value)
                c3.markdown(cond.ideal_range)
                c4.markdown("✅" if cond.met else "❌")

            st.markdown("---")
            pct_met = guide.entry_conditions_met / guide.entry_conditions_total if guide.entry_conditions_total > 0 else 0
            bar_color = "#2ecc71" if pct_met >= 0.8 else "#3498db" if pct_met >= 0.6 else "#f39c12" if pct_met >= 0.4 else "#e74c3c"
            st.markdown(
                f"**Entry Readiness: {guide.entry_conditions_met}/{guide.entry_conditions_total} conditions met**"
            )
            st.progress(pct_met, text=f"{pct_met:.0%}")

            if guide.optimal_entry_price:
                st.markdown(f"💡 **Optimal entry price for {sym}:** ~**${guide.optimal_entry_price:.2f}** — "
                            f"current price is **${current_price:.2f}** "
                            f"({'at target ✅' if abs(current_price - guide.optimal_entry_price) <= indicators.atr_14 * 0.5 else 'wait for price to reach target'})")

        # ── 4.5d: Exit Plan & Trade Management ──
        with st.expander("🚪 Exit Plan & Trade Management", expanded=True):
            ep = guide.exit_plan

            ep1, ep2, ep3, ep4 = st.columns(4)
            ep1.metric("Take Profit", f"${ep.take_profit_price:,.2f}",
                       delta=f"{ep.take_profit_pct:.0%} of max", delta_color="off")
            ep2.metric("Stop Loss", f"${ep.stop_loss_price:,.2f}",
                       delta=f"{ep.stop_loss_pct:.0%}× premium", delta_color="off")
            ep3.metric("Roll Trigger", f"{ep.roll_trigger_dte} DTE",
                       delta="Days to expiration", delta_color="off")
            ep4.metric("Risk/Reward", f"{order.risk_reward_ratio:.3f}",
                       delta="ratio", delta_color="off")

            st.markdown("#### 📌 Management Rules")
            st.markdown(ep.adjustment_notes)

            st.markdown("#### 🔄 Rolling Conditions")
            st.markdown(ep.roll_conditions)

        # ══════════════════════════════════════════════════════════
        #  SECTION 5: Risk Validation
        # ══════════════════════════════════════════════════════════

        st.markdown("## 5️⃣  Risk Validation")

        # Create a mock config with the sidebar parameters
        class SimRiskConfig:
            max_position_size_pct = rcfg.get("max_pos_pct", max_pos_pct)
            max_loss_pct = rcfg.get("max_loss_pct", max_loss_pct)
            max_options_allocation_pct = 0.15
            min_dte = rcfg.get("min_dte", min_dte)
            max_dte = rcfg.get("max_dte", max_dte)
            earnings_blackout_days = 7
            max_daily_trades = 3
            circuit_breaker_daily_loss_pct = 0.03

        rm = RiskManager(cfg=SimRiskConfig())
        risk = rm.validate(order, portfolio, indicators)

        if risk.approved:
            st.success("✅ **Risk Check PASSED** — This trade satisfies all risk guardrails.")
        else:
            st.error("❌ **Risk Check FAILED**")
            for reason in risk.rejection_reasons:
                st.markdown(f"- 🚫 {reason}")

        # Risk breakdown
        rcol1, rcol2, rcol3, rcol4 = st.columns(4)
        rcol1.metric("Position Size", f"{risk.position_size_pct:.2%}", delta="OK" if risk.position_size_pct <= SimRiskConfig.max_position_size_pct else "OVER", delta_color="normal" if risk.position_size_pct <= SimRiskConfig.max_position_size_pct else "inverse")
        rcol2.metric("Max Loss %", f"{risk.max_loss_pct:.2%}", delta="OK" if risk.max_loss_pct <= SimRiskConfig.max_loss_pct else "OVER", delta_color="normal" if risk.max_loss_pct <= SimRiskConfig.max_loss_pct else "inverse")
        rcol3.metric("Options Alloc", f"{risk.options_allocation_after_pct:.2%}")
        rcol4.metric("Portfolio Value", f"${portfolio.account.portfolio_value:,.0f}")

        # ══════════════════════════════════════════════════════════
        #  SECTION 6: Simulation Summary
        # ══════════════════════════════════════════════════════════

        st.markdown("## 6️⃣  Simulation Summary")

        summary = {
            "symbol": sym,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "mode": "🟡 SIMULATION (no real trades)",
            "market_regime": regime_label,
            "recommended_strategy": STRATEGY_DESCRIPTIONS[selected_strategy_name]["name"],
            "simulated_strategy": STRATEGY_DESCRIPTIONS[override_strategy]["name"],
            "order": order.model_dump(),
            "risk_assessment": risk.model_dump(),
            "portfolio": {
                "value": portfolio.account.portfolio_value,
                "cash": portfolio.account.cash,
                "shares_held": pcfg.get("shares", shares),
            },
        }

        with st.expander("📋 Full JSON Summary", expanded=False):
            st.json(summary, expanded=False)

        # Download button
        st.download_button(
            label="📥 Download Simulation Report (JSON)",
            data=json.dumps(summary, indent=2, default=str),
            file_name=f"simulation_{sym}_{date.today().isoformat()}.json",
            mime="application/json",
        )

    except Exception as exc:
        st.error(f"Could not construct order: {exc}")


# ══════════════════════════════════════════════════════════════════
#  SECTION 7: Strategy Comparison
# ══════════════════════════════════════════════════════════════════

st.markdown("---")
st.markdown("## 📚 Strategy Comparison Reference")

comp_data = {
    "": ["🚀 Buy Call (Scalp)", "💥 Buy Put (Scalp)", "Covered Call", "Naked Put", "Naked Call", "Iron Condor", "Protective Put"],
    "Market Regime": ["Any (bullish breakout)", "Any (bearish breakout)", "Low Vol · Bullish", "Low Vol · Neutral", "High Vol · Bearish", "Range-Bound · High Vol", "Trending Bearish"],
    "Direction": ["Strong Bullish", "Strong Bearish", "Mildly Bullish", "Bullish/Neutral", "Bearish/Neutral", "Neutral (range)", "Bearish hedge"],
    "Legs": ["Buy 1 ATM call", "Buy 1 ATM put", "Sell 1 OTM call", "Sell 1 OTM put", "Sell 1 OTM call", "4-leg spread", "Buy 1 ATM put"],
    "Max Profit": ["Unlimited (up)", "Unlimited (down)", "Premium", "Premium", "Premium", "Net credit", "Unlimited (down)"],
    "Max Loss": ["Premium paid", "Premium paid", "Stock → 0", "Strike×100 − prem", "⚠️ UNLIMITED", "Spread width", "Premium paid"],
    "Ideal VIX": ["Any", "Any", "< 20", "< 20", "20 – 40+", "20 – 35", "> 30"],
    "Ideal RSI": ["> 50 (breakout)", "< 50 (breakdown)", "40 – 65", "40 – 60", "> 60 (overbought)", "40 – 60", "< 30 or death cross"],
    "Timeframe": ["⚡ Intraday", "⚡ Intraday", "📅 Daily/Swing", "📅 Daily/Swing", "📅 Daily/Swing", "📅 Daily/Swing", "📅 Daily/Swing"],
    "Shares?": ["❌ Cash only", "❌ Cash only", "✅ ≥100", "❌ Cash only", "❌ Margin", "❌ No", "✅ Any"],
}
st.dataframe(pd.DataFrame(comp_data), hide_index=True, use_container_width=True)

st.markdown("---")
st.caption("🔒 **Simulation Only** — No real trades are placed. "
           + ("🧪 Running in **Mock Mode** with bundled sample data." if mock_mode
              else "📡 Using **live market data** from Yahoo Finance for analysis.")
           + " Option chains are always synthetic.")

