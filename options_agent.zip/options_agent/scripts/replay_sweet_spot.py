#!/usr/bin/env python
"""Replay Sweet Spot Agent — simulates the agent on recent historical days.

Unlike the backtester (which evaluates only at 10:30 with 12 bars),
this replays the FULL day checking every 5 minutes — exactly as the
live agent would operate.

This is an EXACT REPLICA of the live sweet-spot agent logic:
  - Uses OpeningRangeAnalyzer (with bars_5m= for replay)
  - Uses RecentMomentumAnalyzer (with bars_5m= for replay)
  - Uses MomentumCascadeDetector (with bars_5m= for replay)
  - Uses compute_quality_score and compute_choppiness
  - Same entry confirmation, target multipliers, and regime guard

Usage:
    cd options_agent
    python scripts/replay_sweet_spot.py --days 20         # Last 20 trading days
    python scripts/replay_sweet_spot.py --days 60         # Last 60 days
    python scripts/replay_sweet_spot.py --start 2026-04-01 --end 2026-05-01
"""

from __future__ import annotations

import argparse
import logging
import os
import sys
from datetime import date, datetime, timezone

import numpy as np
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src.opening_range import OpeningRangeAnalyzer
from src.recent_momentum import RecentMomentumAnalyzer
from src.momentum_cascade import MomentumCascadeDetector
from src.models.market_data import MarketIndicators
from src.utils.choppiness import compute_choppiness
from src.utils.quality_scorer import compute_quality_score

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)


def _build_indicators_from_bars(bars: pd.DataFrame, symbol: str = "SPY") -> MarketIndicators:
    """Build a MarketIndicators snapshot from historical 5-min bars.

    Mimics what MarketAnalyzer.analyze() produces, but from pre-fetched data
    so we don't hit yfinance during replay.
    """
    close = bars["Close"].astype(float)
    high = bars["High"].astype(float)
    low = bars["Low"].astype(float)
    vol = bars["Volume"].astype(float)
    price = float(close.iloc[-1])

    # RSI
    if len(close) >= 15:
        delta = close.diff()
        gain = delta.where(delta > 0, 0.0).rolling(14).mean()
        loss = (-delta.where(delta < 0, 0.0)).rolling(14).mean()
        rs = gain / loss.replace(0, np.nan)
        rsi_series = 100 - (100 / (1 + rs))
        rsi_val = float(rsi_series.iloc[-1])
        if np.isnan(rsi_val):
            rsi_val = 50.0
    else:
        rsi_val = 50.0

    # SMAs (from intraday bars — same as live agent's 5-min data)
    sma_20 = float(close.iloc[-20:].mean()) if len(close) >= 20 else price
    sma_50 = float(close.iloc[-50:].mean()) if len(close) >= 50 else price
    sma_200 = float(close.iloc[-min(200, len(close)):].mean()) if len(close) >= 20 else price

    # Bollinger Bands
    bb_period = min(20, len(close) - 1) if len(close) > 2 else 2
    bb_mid = float(close.rolling(bb_period).mean().iloc[-1])
    bb_std = float(close.rolling(bb_period).std().iloc[-1]) if bb_period > 1 else 0.0
    bb_upper = bb_mid + 2 * bb_std
    bb_lower = bb_mid - 2 * bb_std

    # MACD
    if len(close) >= 26:
        ema12 = close.ewm(span=12, adjust=False).mean()
        ema26 = close.ewm(span=26, adjust=False).mean()
        macd_line = ema12 - ema26
        signal = macd_line.ewm(span=9, adjust=False).mean()
        hist = macd_line - signal
        macd_val = float(macd_line.iloc[-1])
        macd_sig = float(signal.iloc[-1])
        macd_hist = float(hist.iloc[-1])
    else:
        macd_val = macd_sig = macd_hist = 0.0

    # ATR
    if len(close) >= 15:
        tr = pd.concat([high - low, (high - close.shift()).abs(), (low - close.shift()).abs()], axis=1).max(axis=1)
        atr = float(tr.rolling(14).mean().iloc[-1])
    else:
        atr = 1.0

    # Volume
    current_volume = int(vol.iloc[-1])
    vol_sma_20 = float(vol.rolling(min(20, len(vol))).mean().iloc[-1])

    # ZLEMA
    if len(close) >= 21:
        lag_fast = (8 - 1) // 2
        lag_slow = (21 - 1) // 2
        comp_fast = 2 * close - close.shift(lag_fast)
        comp_slow = 2 * close - close.shift(lag_slow)
        zlema_fast = float(comp_fast.ewm(span=8, adjust=False).mean().iloc[-1])
        zlema_slow = float(comp_slow.ewm(span=21, adjust=False).mean().iloc[-1])
        if zlema_fast > zlema_slow * 1.0002:
            zlema_trend = "bullish"
        elif zlema_fast < zlema_slow * 0.9998:
            zlema_trend = "bearish"
        else:
            zlema_trend = "neutral"
    else:
        zlema_fast = zlema_slow = price
        zlema_trend = "neutral"

    return MarketIndicators(
        symbol=symbol,
        timestamp=datetime.now(timezone.utc),
        current_price=price,
        timeframe="15min",
        vix=20.0,  # Not available in replay — use neutral default
        rsi_14=rsi_val,
        rsi_5min=rsi_val,
        sma_20=sma_20,
        sma_50=sma_50,
        sma_200=sma_200,
        bb_upper=bb_upper,
        bb_middle=bb_mid,
        bb_lower=bb_lower,
        macd=macd_val,
        macd_signal=macd_sig,
        macd_histogram=macd_hist,
        atr_14=atr,
        volume=current_volume,
        volume_sma_20=vol_sma_20,
        zlema_fast=zlema_fast,
        zlema_slow=zlema_slow,
        zlema_trend=zlema_trend,
    )


def replay_day(day_bars: pd.DataFrame, trade_date: date, max_chop: int = 10,
               min_cascade: int = 4, min_quality: int = 4, max_quality: int = 8,
               breakout_pct: float = 0.25, cooldown_bars: int = 3,
               scan_end: str = "13:59",
               scan_start: str = "10:35",
               target_mult_low: float = 1.0, target_mult_mid: float = 1.25,
               target_mult_high: float = 1.5,
               regime_guard: bool = True,
               symbol: str = "SPY",
               max_trades_per_day: int = 0,
               max_stops_per_day: int = 0) -> list[dict]:
    """Replay one day scanning every 5 min window after 10:35.

    Uses the EXACT same analyzers as the live agent:
      - OpeningRangeAnalyzer (with bars_5m=)
      - RecentMomentumAnalyzer (with bars_5m=)
      - MomentumCascadeDetector (with bars_5m=)
      - compute_quality_score
      - compute_choppiness

    Returns list of trigger dicts with simulated outcomes.
    """
    or_analyzer = OpeningRangeAnalyzer()
    rc_analyzer = RecentMomentumAnalyzer()
    cascade_detector = MomentumCascadeDetector()

    # Need bars from 9:30 onward for OR
    or_bars = day_bars.between_time("09:30", "10:29")
    if len(or_bars) < 6:
        return []

    range_high = float(or_bars["High"].max())
    range_low = float(or_bars["Low"].min())
    range_width = range_high - range_low
    if range_width <= 0:
        return []

    # Post-OR bars (10:30 onward) — scan windows
    post_or = day_bars[day_bars.index > or_bars.index[-1]]
    if len(post_or) < 3:
        return []

    triggers = []
    last_trigger_idx = -999
    stops_today = 0  # Track stop-outs for daily loss limit

    # Scan every bar (5 min) from scan_start to scan_end
    scan_bars = post_or.between_time(scan_start, scan_end)

    # ── Precompute cumulative series once for the whole day (perf optimization) ──
    day_close = day_bars["Close"].astype(float)
    day_high = day_bars["High"].astype(float)
    day_low = day_bars["Low"].astype(float)
    day_vol = day_bars["Volume"].astype(float)

    # Precompute RSI components (rolling gain/loss for the whole day)
    day_delta = day_close.diff()
    day_gain = day_delta.where(day_delta > 0, 0.0).rolling(14).mean()
    day_loss = (-day_delta.where(day_delta < 0, 0.0)).rolling(14).mean()
    day_rs = day_gain / day_loss.replace(0, np.nan)
    day_rsi = 100 - (100 / (1 + day_rs))

    # Precompute MACD for the whole day
    day_ema12 = day_close.ewm(span=12, adjust=False).mean()
    day_ema26 = day_close.ewm(span=26, adjust=False).mean()
    day_macd_line = day_ema12 - day_ema26
    day_macd_signal = day_macd_line.ewm(span=9, adjust=False).mean()
    day_macd_hist = day_macd_line - day_macd_signal

    # Precompute ATR for the whole day
    day_tr = pd.concat([day_high - day_low, (day_high - day_close.shift()).abs(),
                        (day_low - day_close.shift()).abs()], axis=1).max(axis=1)
    day_atr = day_tr.rolling(14).mean()

    # Precompute Bollinger Bands
    day_bb_mid = day_close.rolling(20).mean()
    day_bb_std = day_close.rolling(20).std()

    # Precompute ZLEMA
    lag_fast = (8 - 1) // 2
    lag_slow = (21 - 1) // 2
    comp_fast = 2 * day_close - day_close.shift(lag_fast)
    comp_slow = 2 * day_close - day_close.shift(lag_slow)
    day_zlema_fast = comp_fast.ewm(span=8, adjust=False).mean()
    day_zlema_slow = comp_slow.ewm(span=21, adjust=False).mean()

    # Precompute VWAP
    day_typical = (day_high + day_low + day_close) / 3
    day_cumvol = day_vol.cumsum()
    day_cum_tp_vol = (day_typical * day_vol).cumsum()

    # Precompute volume SMA
    day_vol_sma = day_vol.rolling(min(20, len(day_vol))).mean()

    for i, (ts, bar) in enumerate(scan_bars.iterrows()):
        # ── Daily limits ──
        if max_trades_per_day > 0 and len(triggers) >= max_trades_per_day:
            break
        if max_stops_per_day > 0 and stops_today >= max_stops_per_day:
            break

        # Cooldown: skip if triggered within last N bars
        if i - last_trigger_idx < cooldown_bars:
            continue

        # Use all bars up to current time for indicators
        bars_to_now = day_bars[day_bars.index <= ts]
        n = len(bars_to_now)
        price = float(day_close.iloc[:n].iloc[-1])

        # ── Build MarketIndicators from precomputed series (FAST) ──
        rsi_val = float(day_rsi.iloc[:n].iloc[-1]) if n >= 15 and not np.isnan(day_rsi.iloc[:n].iloc[-1]) else 50.0
        sma_20 = float(day_close.iloc[:n].iloc[-20:].mean()) if n >= 20 else price
        sma_50 = float(day_close.iloc[:n].iloc[-50:].mean()) if n >= 50 else price
        sma_200 = float(day_close.iloc[:n].iloc[-min(200, n):].mean()) if n >= 20 else price

        bb_mid_val = float(day_bb_mid.iloc[:n].iloc[-1]) if n >= 20 and not np.isnan(day_bb_mid.iloc[:n].iloc[-1]) else price
        bb_std_val = float(day_bb_std.iloc[:n].iloc[-1]) if n >= 20 and not np.isnan(day_bb_std.iloc[:n].iloc[-1]) else 0.0
        bb_upper = bb_mid_val + 2 * bb_std_val
        bb_lower = bb_mid_val - 2 * bb_std_val

        if n >= 26:
            macd_val = float(day_macd_line.iloc[:n].iloc[-1])
            macd_sig = float(day_macd_signal.iloc[:n].iloc[-1])
            macd_hist_val = float(day_macd_hist.iloc[:n].iloc[-1])
        else:
            macd_val = macd_sig = macd_hist_val = 0.0

        atr_val = float(day_atr.iloc[:n].iloc[-1]) if n >= 15 and not np.isnan(day_atr.iloc[:n].iloc[-1]) else 1.0

        current_volume = int(day_vol.iloc[:n].iloc[-1])
        vol_sma_val = float(day_vol_sma.iloc[:n].iloc[-1]) if not np.isnan(day_vol_sma.iloc[:n].iloc[-1]) else float(current_volume)

        if n >= 21:
            zf = float(day_zlema_fast.iloc[:n].iloc[-1])
            zs = float(day_zlema_slow.iloc[:n].iloc[-1])
            if zf > zs * 1.0002:
                zlema_trend = "bullish"
            elif zf < zs * 0.9998:
                zlema_trend = "bearish"
            else:
                zlema_trend = "neutral"
        else:
            zf = zs = price
            zlema_trend = "neutral"

        indicators = MarketIndicators(
            symbol=symbol,
            timestamp=datetime.now(timezone.utc),
            current_price=price,
            timeframe="15min",
            vix=20.0,
            rsi_14=rsi_val,
            rsi_5min=rsi_val,
            sma_20=sma_20,
            sma_50=sma_50,
            sma_200=sma_200,
            bb_upper=bb_upper,
            bb_middle=bb_mid_val,
            bb_lower=bb_lower,
            macd=macd_val,
            macd_signal=macd_sig,
            macd_histogram=macd_hist_val,
            atr_14=atr_val,
            volume=current_volume,
            volume_sma_20=vol_sma_val,
            zlema_fast=zf,
            zlema_slow=zs,
            zlema_trend=zlema_trend,
        )

        # ── Opening Range Analysis (EXACT same as live agent) ──
        or_result = or_analyzer.analyze(indicators, bars_5m=bars_to_now)
        or_direction = or_result.breakout_direction.value  # "bullish", "bearish", "neutral"
        or_momentum = or_result.momentum_score

        # ── Recent Momentum Analysis (EXACT same as live agent) ──
        rc_result = rc_analyzer.analyze(indicators, bars_5m=bars_to_now)
        recent_dir = rc_result.direction
        recent_momentum = rc_result.momentum_score

        # ── Direction decision (same as live agent) ──
        if or_momentum >= 25:
            direction = "buy_call"
        elif or_momentum <= -25:
            direction = "buy_put"
        else:
            continue

        # ── Regime guard (same as live agent dashboard guardrails) ──
        if regime_guard:
            rsi_val = indicators.rsi_14
            sma_20 = indicators.sma_20
            sma_50 = indicators.sma_50
            bullish_regime = sma_20 > sma_50
            bearish_regime = sma_20 < sma_50

            if direction == "buy_put" and bullish_regime and rsi_val <= 70:
                continue
            if direction == "buy_call" and bearish_regime and rsi_val >= 30:
                continue

        # ── Quality Score (EXACT same as live agent) ──
        quality_result = compute_quality_score(
            direction=direction,
            current_price=indicators.current_price,
            sma_20=indicators.sma_20,
            sma_50=indicators.sma_50,
            vix=indicators.vix,
            volume=1.0,
            volume_sma_20=1.0,
            or_direction=or_direction,
            or_momentum=or_momentum,
            or_confirmed=abs(or_momentum) >= 40,
            recent_dir=recent_dir,
            recent_momentum=recent_momentum,
        )
        quality = quality_result.score

        if not (min_quality <= quality <= max_quality):
            continue

        # ── Momentum Cascade (EXACT same as live agent) ──
        cascade = cascade_detector.analyze(
            indicators,
            quality_score=quality,
            or_momentum=or_momentum,
            recent_momentum=recent_momentum,
            bars_5m=bars_to_now,
        )
        explosion = cascade.explosion_score

        if explosion < min_cascade:
            continue

        # ── Choppiness ──
        chop = compute_choppiness(bars_to_now)
        if chop.chop_score > max_chop:
            continue

        # ── TRIGGER! ──
        last_trigger_idx = i

        # ── Entry confirmation: price must be in upper/lower N% of range or beyond ──
        breakout_threshold = range_width * breakout_pct
        if direction == "buy_call" and price < (range_high - breakout_threshold):
            continue
        if direction == "buy_put" and price > (range_low + breakout_threshold):
            continue

        # Target mult (same as live agent)
        if explosion >= 8:
            target_mult = target_mult_high
        elif explosion >= 6:
            target_mult = target_mult_mid
        else:
            target_mult = target_mult_low

        if direction == "buy_call":
            entry = price
            stop = (range_high + range_low) / 2
            risk = entry - stop
            if risk <= 0:
                continue
            target = entry + risk * target_mult
        else:
            entry = price
            stop = (range_high + range_low) / 2
            risk = stop - entry
            if risk <= 0:
                continue
            target = entry - risk * target_mult

        # ── Walk forward to determine outcome ──
        future_bars = day_bars[day_bars.index > ts]
        outcome = "eod"
        exit_price = float(future_bars["Close"].iloc[-1]) if len(future_bars) > 0 else price

        for _, fb in future_bars.iterrows():
            fh, fl, fc = float(fb["High"]), float(fb["Low"]), float(fb["Close"])
            if direction == "buy_call":
                if fl <= stop:
                    outcome = "stop"; exit_price = stop; break
                if fh >= target:
                    outcome = "target"; exit_price = target; break
            else:
                if fh >= stop:
                    outcome = "stop"; exit_price = stop; break
                if fl <= target:
                    outcome = "target"; exit_price = target; break

            # Time stop 15:30
            if fb.name.strftime("%H:%M") >= "15:30":
                outcome = "time_stop"; exit_price = fc; break

        pnl = (exit_price - entry) if direction == "buy_call" else (entry - exit_price)

        if outcome == "stop":
            stops_today += 1

        triggers.append({
            "date": str(trade_date),
            "time": ts.strftime("%H:%M"),
            "direction": direction,
            "quality": quality,
            "explosion": explosion,
            "chop": chop.chop_score,
            "momentum": or_momentum,
            "recent_momentum": recent_momentum,
            "entry": round(entry, 2),
            "stop": round(stop, 2),
            "target": round(target, 2),
            "target_mult": target_mult,
            "exit_price": round(exit_price, 2),
            "outcome": outcome,
            "pnl": round(pnl, 4),
            "is_winner": pnl > 0,
        })

    return triggers


def main():
    parser = argparse.ArgumentParser(description="Replay Sweet Spot Agent on historical data")
    parser.add_argument("--symbol", "-s", default="SPY")
    parser.add_argument("--days", type=int, default=30, help="Number of recent trading days")
    parser.add_argument("--max-chop", type=int, default=10)
    parser.add_argument("--multi", action="store_true", help="Allow multiple triggers per day")
    parser.add_argument("--min-quality", type=int, default=4, help="Minimum quality score")
    parser.add_argument("--max-quality", type=int, default=8, help="Maximum quality score")
    parser.add_argument("--min-cascade", type=int, default=4, help="Minimum cascade proxy")
    parser.add_argument("--breakout-pct", type=float, default=0.25, help="Breakout percentage of range")
    parser.add_argument("--cooldown-bars", type=int, default=3, help="Cooldown period in bars")
    parser.add_argument("--scan-end", type=str, default="13:59", help="End time for scanning (HH:MM)")
    parser.add_argument("--target-mult-low", type=float, default=1.0, help="Target multiple for low explosion")
    parser.add_argument("--target-mult-mid", type=float, default=1.25, help="Target multiple for mid explosion")
    parser.add_argument("--target-mult-high", type=float, default=1.5, help="Target multiple for high explosion")
    parser.add_argument("--no-regime-guard", action="store_true", help="Disable regime guardrails")
    parser.add_argument("--scan-start", type=str, default="10:35", help="Start time for scanning (HH:MM)")
    parser.add_argument("--max-trades-per-day", type=int, default=0, help="Max trades per day (0=unlimited)")
    parser.add_argument("--max-stops-per-day", type=int, default=0, help="Stop trading after N stop-outs (0=unlimited)")
    args = parser.parse_args()

    # Fetch data via Alpaca
    try:
        from src.utils.alpaca_data import fetch_bars
        logger.info("Fetching %d days of 5-min data from Alpaca for %s...", args.days, args.symbol)
        df = fetch_bars(args.symbol, days_back=args.days, interval="5min")
    except Exception as e:
        logger.warning("Alpaca failed (%s), trying yfinance...", e)
        import yfinance as yf
        period = f"{args.days}d" if args.days <= 60 else "60d"
        df = yf.download(args.symbol, period=period, interval="5m", progress=False)
        if isinstance(df.columns, pd.MultiIndex):
            df.columns = df.columns.get_level_values(0)
        df.index = pd.to_datetime(df.index)
        if df.index.tz is None:
            df.index = df.index.tz_localize("UTC")
        df.index = df.index.tz_convert("US/Eastern")

    if df.empty:
        print("No data available")
        return

    trading_days = sorted(set(df.index.date))
    logger.info("Replaying %d trading days...", len(trading_days))

    all_triggers = []
    for day in trading_days:
        day_bars = df[df.index.date == day]
        if len(day_bars) < 24:
            continue
        triggers = replay_day(day_bars, day, max_chop=args.max_chop,
                              min_quality=args.min_quality, max_quality=args.max_quality,
                              min_cascade=args.min_cascade, breakout_pct=args.breakout_pct,
                              cooldown_bars=args.cooldown_bars, scan_end=args.scan_end,
                              scan_start=args.scan_start,
                              target_mult_low=args.target_mult_low, target_mult_mid=args.target_mult_mid,
                              target_mult_high=args.target_mult_high,
                              regime_guard=not args.no_regime_guard,
                              symbol=args.symbol,
                              max_trades_per_day=args.max_trades_per_day,
                              max_stops_per_day=args.max_stops_per_day)
        all_triggers.extend(triggers)

    # ── Results ──
    print(f"\n{'═' * 70}")
    print(f"  SWEET SPOT REPLAY: {args.symbol} — {len(trading_days)} days")
    print(f"  Filter: Quality {args.min_quality}-{args.max_quality}, Cascade ≥ {args.min_cascade}, Chop ≤ {args.max_chop}, Regime Guard: {'ON' if not args.no_regime_guard else 'OFF'}")
    print(f"  Analyzers: OpeningRange + RecentMomentum + MomentumCascade (exact replica)")
    print(f"{'═' * 70}")

    if not all_triggers:
        print("\n  No sweet spot triggers found in this period.")
        return

    wins = [t for t in all_triggers if t["is_winner"]]
    losses = [t for t in all_triggers if not t["is_winner"]]
    total_pnl = sum(t["pnl"] for t in all_triggers)
    avg_pnl = total_pnl / len(all_triggers)
    win_rate = len(wins) / len(all_triggers) * 100
    avg_win = np.mean([t["pnl"] for t in wins]) if wins else 0
    avg_loss = np.mean([t["pnl"] for t in losses]) if losses else 0
    gross_profit = sum(t["pnl"] for t in wins)
    gross_loss = abs(sum(t["pnl"] for t in losses))
    pf = gross_profit / gross_loss if gross_loss > 0 else float("inf")

    print(f"\n  Triggers:        {len(all_triggers)} ({len(all_triggers)/len(trading_days):.1f}/day)")
    print(f"  Win Rate:        {win_rate:.1f}% ({len(wins)}/{len(all_triggers)})")
    print(f"  Profit Factor:   {pf:.2f}")
    print(f"  Total P&L:       ${total_pnl:+.2f}")
    print(f"  Avg P&L/Trade:   ${avg_pnl:+.4f}")
    print(f"  Avg Winner:      ${avg_win:+.4f}")
    print(f"  Avg Loser:       ${avg_loss:+.4f}")
    print(f"  R:R Ratio:       {abs(avg_win/avg_loss):.2f}" if avg_loss != 0 else "")

    # Outcomes
    outcomes = {}
    for t in all_triggers:
        outcomes[t["outcome"]] = outcomes.get(t["outcome"], 0) + 1
    print(f"\n  Exit Breakdown:")
    for o, c in sorted(outcomes.items(), key=lambda x: -x[1]):
        print(f"    {o:<12} {c:>3} ({c/len(all_triggers)*100:.0f}%)")

    # Trade log
    print(f"\n  {'Date':<12} {'Time':<6} {'Dir':<5} {'Q':>2} {'E':>2} {'C':>2} {'Mult':>5} {'Entry':>8} {'Exit':>8} {'P&L':>8} {'Outcome':<8}")
    print(f"  {'─'*12} {'─'*6} {'─'*5} {'─'*2} {'─'*2} {'─'*2} {'─'*5} {'─'*8} {'─'*8} {'─'*8} {'─'*8}")
    for t in all_triggers:
        d = "CALL" if "call" in t["direction"] else "PUT"
        w = "✅" if t["is_winner"] else "❌"
        print(f"  {t['date']:<12} {t['time']:<6} {d:<5} {t['quality']:>2} {t['explosion']:>2} {t['chop']:>2} {t['target_mult']:>4.2f}x ${t['entry']:>7.2f} ${t['exit_price']:>7.2f} ${t['pnl']:>+7.2f} {t['outcome']:<8} {w}")


if __name__ == "__main__":
    main()

