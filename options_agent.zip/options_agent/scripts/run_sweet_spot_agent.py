#!/usr/bin/env python
"""Autonomous Sweet Spot Agent — runs every trading day, paper trades sweet spots.

This agent:
  1. Starts at 9:30 AM ET on weekdays
  2. Scans for sweet spots every 5 minutes until 3:30 PM
  3. Places bracket orders on Alpaca paper account when triggered
  4. Logs all activity to sweet_spot_journal/
  5. Sends a daily summary at market close

Run as a background service:
    # One-time test
    python scripts/run_sweet_spot_agent.py

    # Daemonized (keeps running daily)
    python scripts/run_sweet_spot_agent.py --daemon

    # With custom settings
    python scripts/run_sweet_spot_agent.py --daemon --qty 10 --max-chop 5

Schedule with cron/launchd (alternative to --daemon):
    # crontab -e
    30 9 * * 1-5 cd /path/to/options_agent && python scripts/run_sweet_spot_agent.py >> logs/agent.log 2>&1
"""

from __future__ import annotations

import argparse
import json
import logging
import os
import sys
import time
from datetime import date, datetime, timedelta
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from dotenv import load_dotenv
load_dotenv()

import pandas as pd
import yfinance as yf

from src.market_analyzer import MarketAnalyzer
from src.opening_range import OpeningRangeAnalyzer
from src.recent_momentum import RecentMomentumAnalyzer
from src.momentum_cascade import MomentumCascadeDetector
from src.utils.quality_scorer import compute_quality_score
from src.utils.choppiness import compute_choppiness

# ── Setup ──
LOG_DIR = Path(__file__).resolve().parent.parent / "logs"
LOG_DIR.mkdir(exist_ok=True)
JOURNAL_DIR = Path(__file__).resolve().parent.parent / "sweet_spot_journal"
JOURNAL_DIR.mkdir(exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler(LOG_DIR / "sweet_spot_agent.log"),
    ],
)
logger = logging.getLogger("sweet_spot_agent")


def get_et_now() -> datetime:
    from zoneinfo import ZoneInfo
    return datetime.now(ZoneInfo("US/Eastern"))


def is_market_hours() -> bool:
    now = get_et_now()
    if now.weekday() >= 5:
        return False
    return now.hour * 60 + now.minute >= 9 * 60 + 30 and now.hour < 16


def is_past_or(min_after_open: int = 65) -> bool:
    """Wait until at least 65 min after open (10:35) for OR to form."""
    now = get_et_now()
    minutes_since_open = (now.hour * 60 + now.minute) - (9 * 60 + 30)
    return minutes_since_open >= min_after_open


def check_sweet_spot(symbol: str, max_chop: int = 5) -> dict | None:
    """Evaluate sweet spot conditions. Returns trigger dict or None."""
    try:
        analyzer = MarketAnalyzer()
        indicators = analyzer.analyze(symbol, timeframe="15min")

        or_analyzer = OpeningRangeAnalyzer()
        or_result = or_analyzer.analyze(symbol)
        or_direction = or_result.direction if or_result else "neutral"
        or_momentum = or_result.momentum_score if or_result else 0

        rc_analyzer = RecentMomentumAnalyzer()
        rc_result = rc_analyzer.analyze(symbol)
        recent_dir = rc_result.direction if rc_result else "neutral"
        recent_momentum = rc_result.momentum_score if rc_result else 0

        direction = "buy_call" if or_momentum >= 25 else "buy_put" if or_momentum <= -25 else None
        if direction is None:
            return None

        quality_result = compute_quality_score(
            direction=direction,
            current_price=indicators.current_price,
            sma_20=indicators.sma_20,
            sma_50=indicators.sma_50,
            vix=indicators.vix,
            volume=1.0,
            volume_sma_20=1.0,
            or_direction=or_direction,
            or_momentum=or_momentum,
            or_confirmed=abs(or_momentum) >= 40,
            recent_dir=recent_dir,
            recent_momentum=recent_momentum,
        )
        quality = quality_result.score

        cascade = MomentumCascadeDetector().analyze(
            indicators, quality_score=quality,
            or_momentum=or_momentum, recent_momentum=recent_momentum,
        )

        bars = yf.download(symbol, period="1d", interval="5m", progress=False)
        if isinstance(bars.columns, pd.MultiIndex):
            bars.columns = bars.columns.get_level_values(0)
        chop = compute_choppiness(bars)

        # Sweet spot criteria
        if not (4 <= quality <= 8):
            return None
        if cascade.explosion_score < 4:
            return None
        if chop.chop_score > max_chop:
            return None

        now = get_et_now()
        range_high = or_result.range_high if or_result else indicators.current_price
        range_low = or_result.range_low if or_result else indicators.current_price
        range_width = range_high - range_low

        # ── Entry confirmation: price must be in upper/lower 25% of range or beyond ──
        breakout_threshold = range_width * 0.25
        if direction == "buy_call" and indicators.current_price < (range_high - breakout_threshold):
            return None
        if direction == "buy_put" and indicators.current_price > (range_low + breakout_threshold):
            return None

        # Target multiplier scales with cascade strength
        if cascade.explosion_score >= 8:
            target_mult = 1.5  # Explosive — let it run
        elif cascade.explosion_score >= 6:
            target_mult = 1.25  # Strong — extended target
        else:
            target_mult = 1.0  # Moderate — standard 1R

        if direction == "buy_call":
            entry = range_high + range_width * 0.10
            stop = (range_high + range_low) / 2
            risk = entry - stop
            target_1 = entry + risk * target_mult
        else:
            entry = range_low - range_width * 0.10
            stop = (range_high + range_low) / 2
            risk = stop - entry
            target_1 = entry - risk * target_mult

        return {
            "timestamp": now.isoformat(),
            "time": now.strftime("%H:%M"),
            "symbol": symbol,
            "direction": direction,
            "price": indicators.current_price,
            "quality": quality,
            "explosion": cascade.explosion_score,
            "chop": chop.chop_score,
            "or_momentum": or_momentum,
            "recent_momentum": recent_momentum,
            "entry": round(entry, 2),
            "stop": round(stop, 2),
            "target": round(target_1, 2),
            "target_mult": target_mult,
            "range_high": round(range_high, 2),
            "range_low": round(range_low, 2),
        }

    except Exception as e:
        logger.error("Sweet spot check failed: %s", e)
        return None


def run_day(symbol: str, qty: int, max_chop: int, paper_trade: bool,
            max_trades_per_day: int = 3, max_stops_per_day: int = 2,
            scan_start_min: int = 120):
    """Run the agent for one trading day."""
    today = date.today()
    journal_file = JOURNAL_DIR / f"{today.isoformat()}.json"
    triggers = json.loads(journal_file.read_text()) if journal_file.exists() else []

    trader = None
    if paper_trade:
        try:
            from src.utils.alpaca_paper import AlpacaPaperTrader
            trader = AlpacaPaperTrader()
            pnl = trader.get_today_pnl()
            logger.info("Paper account: $%.0f equity, $%.0f buying power", pnl["equity"], pnl["buying_power"])
        except Exception as e:
            logger.error("Paper trader init failed: %s — running journal-only", e)

    logger.info("═══ Sweet Spot Agent: %s — %s ═══", symbol, today)
    logger.info("Settings: qty=%d, max_chop=%d, max_trades=%d, max_stops=%d, scan_start=%dmin, paper=%s",
                qty, max_chop, max_trades_per_day, max_stops_per_day, scan_start_min, bool(trader))

    last_trigger = None
    scan_count = 0
    trades_today = 0
    stops_today = 0

    while True:
        now = get_et_now()

        # Exit after 2:00 PM (no new trades after this)
        if now.hour >= 14:
            break

        if not is_market_hours():
            if now.hour >= 16:
                break
            time.sleep(60)
            continue

        # Wait for OR to form + scan start delay
        if not is_past_or(min_after_open=scan_start_min):
            logger.info("Waiting for scan window (OR + %d min)...", scan_start_min)
            time.sleep(60)
            continue

        # ── Daily limits ──
        if max_trades_per_day > 0 and trades_today >= max_trades_per_day:
            logger.info("Daily trade limit reached (%d/%d). Waiting for EOD.", trades_today, max_trades_per_day)
            break
        if max_stops_per_day > 0 and stops_today >= max_stops_per_day:
            logger.info("Daily stop limit reached (%d/%d). Halting for protection.", stops_today, max_stops_per_day)
            break

        scan_count += 1
        trigger = check_sweet_spot(symbol, max_chop=max_chop)

        if trigger:
            # Deduplicate (15 min cooldown)
            if last_trigger and (now - last_trigger).total_seconds() < 900:
                logger.debug("Skipping duplicate trigger within 15 min")
            else:
                last_trigger = now
                trades_today += 1
                triggers.append(trigger)
                journal_file.write_text(json.dumps(triggers, indent=2, default=str))

                dir_label = "CALL" if "call" in trigger["direction"] else "PUT"
                logger.info(
                    "⚡ SWEET SPOT: %s %s Q=%d E=%d C=%d Mom=%+d "
                    "Entry=$%.2f Stop=$%.2f Target=$%.2f",
                    dir_label, symbol, trigger["quality"], trigger["explosion"],
                    trigger["chop"], trigger["or_momentum"],
                    trigger["entry"], trigger["stop"], trigger["target"],
                )

                if trader:
                    try:
                        order = trader.place_sweet_spot_trade(
                            symbol=symbol,
                            direction=trigger["direction"],
                            qty=qty,
                            entry=None,  # Market for immediate fill
                            stop=trigger["stop"],
                            target=trigger["target"],
                            time_in_force="day",
                        )
                        trigger["order_id"] = order["order_id"]
                        journal_file.write_text(json.dumps(triggers, indent=2, default=str))
                        logger.info("  📝 Order placed: %s", order["order_id"][:12])
                    except Exception as e:
                        logger.error("  ⚠️ Order failed: %s", e)

        time.sleep(300)  # 5 min interval

    # ── EOD Summary ──
    logger.info("═══ EOD Summary: %d scans, %d triggers ═══", scan_count, len(triggers))
    if trader:
        try:
            pnl = trader.get_today_pnl()
            logger.info("  Paper P&L: $%.2f (%.2f%%)", pnl["today_pnl"], pnl["today_pnl_pct"])
            positions = trader.get_positions()
            if positions:
                logger.info("  Open positions:")
                for p in positions:
                    logger.info("    %s: %s @ $%.2f (P&L: $%.2f)",
                                p["symbol"], p["qty"], p["entry_price"], p["unrealized_pnl"])
        except Exception as e:
            logger.error("  EOD summary failed: %s", e)


def main():
    parser = argparse.ArgumentParser(description="Autonomous Sweet Spot Paper Trading Agent")
    parser.add_argument("--symbol", "-s", default="SPY", help="Symbol to monitor (default: SPY)")
    parser.add_argument("--qty", type=int, default=1, help="Shares per trade (default: 1)")
    parser.add_argument("--max-chop", type=int, default=5, help="Max choppiness (default: 5)")
    parser.add_argument("--max-trades-per-day", type=int, default=3, help="Max trades per day (default: 3)")
    parser.add_argument("--max-stops-per-day", type=int, default=2, help="Halt after N stop-outs (default: 2)")
    parser.add_argument("--scan-start-min", type=int, default=120, help="Minutes after open to start scanning (default: 120 = 11:30)")
    parser.add_argument("--daemon", action="store_true", help="Run continuously (restarts daily)")
    parser.add_argument("--no-paper", action="store_true", help="Journal only, no paper orders")
    args = parser.parse_args()

    paper_trade = not args.no_paper

    if args.daemon:
        logger.info("Starting in daemon mode — will run every trading day")
        while True:
            now = get_et_now()
            # Only run on weekdays
            if now.weekday() < 5:
                if now.hour < 9 or (now.hour == 9 and now.minute < 25):
                    # Wait until 9:25 AM
                    wait_until = now.replace(hour=9, minute=25, second=0, microsecond=0)
                    sleep_sec = (wait_until - now).total_seconds()
                    logger.info("Sleeping %.0f min until pre-market...", sleep_sec / 60)
                    time.sleep(max(sleep_sec, 60))
                elif now.hour < 16:
                    run_day(args.symbol, args.qty, args.max_chop, paper_trade, max_trades_per_day=args.max_trades_per_day, max_stops_per_day=args.max_stops_per_day, scan_start_min=args.scan_start_min)
                    # After market close, sleep until next day 9:25 AM
                    tomorrow_925 = (now + timedelta(days=1)).replace(hour=9, minute=25, second=0)
                    sleep_sec = (tomorrow_925 - get_et_now()).total_seconds()
                    logger.info("Market closed. Sleeping %.1f hours until tomorrow...", sleep_sec / 3600)
                    time.sleep(max(sleep_sec, 3600))
                else:
                    # After hours — sleep until tomorrow
                    time.sleep(3600)
            else:
                # Weekend — sleep until Monday 9:25
                days_until_monday = (7 - now.weekday()) % 7 or 7
                monday = (now + timedelta(days=days_until_monday)).replace(hour=9, minute=25, second=0)
                sleep_sec = (monday - now).total_seconds()
                logger.info("Weekend. Sleeping %.1f hours until Monday...", sleep_sec / 3600)
                time.sleep(max(sleep_sec, 3600))
    else:
        # Single day run
        run_day(args.symbol, args.qty, args.max_chop, paper_trade, max_trades_per_day=args.max_trades_per_day, max_stops_per_day=args.max_stops_per_day, scan_start_min=args.scan_start_min)


if __name__ == "__main__":
    main()

