"""Market Analyzer — fetches data and computes technical indicators + regime classification."""

from __future__ import annotations

import logging
from datetime import date, datetime, timezone

import numpy as np
import pandas as pd
import yfinance as yf

from src.models.market_data import MarketIndicators, MarketRegime

logger = logging.getLogger(__name__)


class MarketAnalyzer:
    """Compute technical indicators for a symbol and classify the market regime."""

    # Timeframe → (yfinance period, yfinance interval, label)
    TIMEFRAME_CONFIG = {
        "15min": {"period": "5d", "interval": "15m", "label": "Intraday 15-min"},
        "1hour": {"period": "1mo", "interval": "1h", "label": "Intraday 1-hour"},
        "daily": {"period": "1y", "interval": "1d", "label": "Daily"},
        "weekly": {"period": "2y", "interval": "1wk", "label": "Weekly"},
    }

    # ── Public API ────────────────────────────────────────────────

    def analyze(self, symbol: str, timeframe: str = "daily") -> MarketIndicators:
        """Fetch OHLCV data for the given timeframe and compute all indicators.

        Args:
            symbol: Stock ticker (e.g. "AAPL").
            timeframe: One of "15min", "1hour", "daily", "weekly".
        """
        tf = self.TIMEFRAME_CONFIG.get(timeframe, self.TIMEFRAME_CONFIG["daily"])
        logger.info("Analyzing %s on %s timeframe …", symbol, tf["label"])

        df = yf.download(symbol, period=tf["period"], interval=tf["interval"], progress=False)
        if df.empty:
            raise ValueError(f"No data returned for {symbol} ({tf['label']})")

        # Flatten MultiIndex columns if present (yfinance ≥0.2.40)
        if isinstance(df.columns, pd.MultiIndex):
            df.columns = df.columns.get_level_values(0)

        vix_df = yf.download("^VIX", period="5d", interval="1d", progress=False)
        if isinstance(vix_df.columns, pd.MultiIndex):
            vix_df.columns = vix_df.columns.get_level_values(0)
        vix = float(vix_df["Close"].iloc[-1])

        close = df["Close"].astype(float)
        high = df["High"].astype(float)
        low = df["Low"].astype(float)
        current_price = float(close.iloc[-1])

        # Adapt indicator windows per timeframe
        # For intraday: shorter bars → more bars per equivalent period
        # For weekly: fewer bars per equivalent period
        if timeframe == "15min":
            rsi_period, sma_short, sma_mid, sma_long, bb_period, atr_period = 14, 20, 50, 200, 20, 14
        elif timeframe == "1hour":
            rsi_period, sma_short, sma_mid, sma_long, bb_period, atr_period = 14, 20, 50, 200, 20, 14
        elif timeframe == "weekly":
            # Weekly: 10w ≈ 50d, 20w ≈ 100d, 40w ≈ 200d
            rsi_period, sma_short, sma_mid, sma_long, bb_period, atr_period = 14, 10, 20, 40, 10, 14
        else:  # daily (default)
            rsi_period, sma_short, sma_mid, sma_long, bb_period, atr_period = 14, 20, 50, 200, 20, 14

        # RSI
        rsi = self._rsi(close, rsi_period)

        # SMAs
        sma_20 = float(close.rolling(sma_short).mean().iloc[-1])
        sma_50 = float(close.rolling(sma_mid).mean().iloc[-1])
        sma_200 = float(close.rolling(min(sma_long, len(close) - 1)).mean().iloc[-1])

        # Bollinger Bands
        bb_mid = float(close.rolling(bb_period).mean().iloc[-1])
        bb_std = float(close.rolling(bb_period).std().iloc[-1])
        bb_upper = bb_mid + 2 * bb_std
        bb_lower = bb_mid - 2 * bb_std

        # MACD (12, 26, 9)
        macd_line, macd_signal, macd_hist = self._macd(close)

        # ATR
        atr = self._atr(high, low, close, atr_period)

        # Volume
        vol = df["Volume"].astype(float)
        current_volume = int(vol.iloc[-1])
        volume_sma_20 = float(vol.rolling(min(20, len(vol))).mean().iloc[-1])

        # Earnings date (best-effort)
        next_earnings, days_to_earn = self._next_earnings(symbol)

        indicators = MarketIndicators(
            symbol=symbol,
            timestamp=datetime.now(timezone.utc),
            current_price=current_price,
            timeframe=timeframe,
            vix=vix,
            rsi_14=rsi,
            sma_20=sma_20,
            sma_50=sma_50,
            sma_200=sma_200,
            bb_upper=bb_upper,
            bb_middle=bb_mid,
            bb_lower=bb_lower,
            macd=macd_line,
            macd_signal=macd_signal,
            macd_histogram=macd_hist,
            atr_14=atr,
            volume=current_volume,
            volume_sma_20=volume_sma_20,
            next_earnings_date=next_earnings,
            days_to_earnings=days_to_earn,
        )
        logger.info("Indicators for %s: VIX=%.1f RSI=%.1f SMA50=%.2f", symbol, vix, rsi, sma_50)
        return indicators

    def classify_regime(self, ind: MarketIndicators) -> MarketRegime:
        """Rule-based market regime classification."""

        death_cross = ind.sma_50 < ind.sma_200

        # High-vol bearish
        if ind.vix > 30 and (ind.rsi_14 > 70 or death_cross):
            return MarketRegime.HIGH_VOL_BEARISH

        # Trending bearish (death cross + negative MACD)
        if death_cross and ind.macd_histogram < 0:
            return MarketRegime.TRENDING_BEARISH

        # Range-bound high-vol (VIX 20-35, price within Bollinger, neutral RSI)
        if 20 <= ind.vix <= 35 and ind.bb_lower <= ind.current_price <= ind.bb_upper and 40 <= ind.rsi_14 <= 60:
            return MarketRegime.RANGE_BOUND_HV

        # Low-vol bullish (VIX<20, price above 50-SMA, RSI 40-65)
        if ind.vix < 20 and ind.current_price > ind.sma_50 and 40 <= ind.rsi_14 <= 65:
            return MarketRegime.LOW_VOL_BULLISH

        # Low-vol neutral (fallback low-vol)
        if ind.vix < 20:
            return MarketRegime.LOW_VOL_NEUTRAL

        # Default: range-bound high-vol
        return MarketRegime.RANGE_BOUND_HV

    # ── Private Helpers ───────────────────────────────────────────

    @staticmethod
    def _rsi(close: pd.Series, period: int) -> float:
        delta = close.diff()
        gain = delta.where(delta > 0, 0.0).rolling(period).mean()
        loss = (-delta.where(delta < 0, 0.0)).rolling(period).mean()
        rs = gain / loss.replace(0, np.nan)
        rsi = 100 - (100 / (1 + rs))
        return float(rsi.iloc[-1])

    @staticmethod
    def _macd(close: pd.Series) -> tuple[float, float, float]:
        ema12 = close.ewm(span=12, adjust=False).mean()
        ema26 = close.ewm(span=26, adjust=False).mean()
        macd_line = ema12 - ema26
        signal = macd_line.ewm(span=9, adjust=False).mean()
        hist = macd_line - signal
        return float(macd_line.iloc[-1]), float(signal.iloc[-1]), float(hist.iloc[-1])

    @staticmethod
    def _atr(high: pd.Series, low: pd.Series, close: pd.Series, period: int) -> float:
        tr = pd.concat(
            [high - low, (high - close.shift()).abs(), (low - close.shift()).abs()],
            axis=1,
        ).max(axis=1)
        return float(tr.rolling(period).mean().iloc[-1])

    @staticmethod
    def _next_earnings(symbol: str) -> tuple[date | None, int | None]:
        try:
            ticker = yf.Ticker(symbol)
            cal = ticker.calendar
            if cal is not None and not cal.empty:
                earn_date = pd.Timestamp(cal.iloc[0, 0]).date()
                days = (earn_date - date.today()).days
                return earn_date, days
        except Exception:
            pass
        return None, None



