"""Shared 9-point quality scorer for Buy Call / Buy Put strategies.

Used by:
  - dashboard/app.py (auto-selection between strategies)
  - src/strategies/buy_call.py (order construction quality gate)
  - src/strategies/buy_put.py  (order construction quality gate)
  - src/backtester.py          (backtest quality filter)

Scoring criteria (max 9, min 0 after penalties):

  Opening Range (60-min):
    #1  Breakout direction aligned   +2  (or −1 if against)
    #2  Breakout confirmed (|M|≥40)  +1

  Recent 30-Min Momentum:
    #3  Recent direction aligned     +2  (or −1 if against)

  Daily Indicators:
    #4  Volume surge (V/SMA20 ≥ 1.2) +1
    #5  VIX elevated (> 18)          +1
    #6  VWAP confirmation            +1
    #7  Trend alignment (SMA20 vs 50)+1
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass
class QualityResult:
    """Result of the 9-point quality scoring."""
    score: int               # 0-9
    label: str               # "🟢 HIGH", "🔵 MEDIUM", "🟡 LOW"
    confirmations: list[str] # human-readable confirmation descriptions
    cautions: list[str]      # human-readable caution descriptions


def compute_quality_score(
    *,
    direction: str,           # "buy_call" or "buy_put"
    current_price: float,
    sma_20: float,
    sma_50: float,
    vix: float,
    volume: float,
    volume_sma_20: float,
    or_direction: str,        # "bullish", "bearish", "neutral"
    or_momentum: int,         # -100 to +100
    or_confirmed: bool,       # |momentum| >= 40
    recent_dir: str,          # "bullish", "bearish", "neutral"
    recent_momentum: int,     # -100 to +100
) -> QualityResult:
    """Compute quality score (0-9) combining opening range + recent momentum + daily signals."""
    score = 0
    confirmations: list[str] = []
    cautions: list[str] = []

    # ── Opening Range Signals (60-min, 9:30–10:30) ──────────────

    # #1 Breakout direction alignment (STRONGEST signal for scalping, +2)
    if direction == "buy_call" and or_direction == "bullish":
        score += 2
        confirmations.append(f"✅ 60-min breakout is BULLISH (momentum {or_momentum:+d}) — aligned with Buy Call (+2)")
    elif direction == "buy_put" and or_direction == "bearish":
        score += 2
        confirmations.append(f"✅ 60-min breakout is BEARISH (momentum {or_momentum:+d}) — aligned with Buy Put (+2)")
    elif or_direction == "neutral":
        cautions.append(f"⚠️ 60-min breakout is NEUTRAL (momentum {or_momentum:+d}) — no directional edge")
    else:
        score -= 1
        cautions.append(f"🚫 60-min breakout is {or_direction.upper()} — AGAINST {direction.replace('_', ' ')} (−1)")

    # #2 Breakout confirmed (|momentum| >= 40, +1)
    if or_confirmed:
        if (direction == "buy_call" and or_momentum > 0) or (direction == "buy_put" and or_momentum < 0):
            score += 1
            confirmations.append(f"✅ Breakout CONFIRMED (|momentum|={abs(or_momentum)} ≥ 40) (+1)")
        else:
            cautions.append(f"⚠️ Breakout confirmed but in wrong direction (momentum {or_momentum:+d})")
    else:
        cautions.append(f"⏳ Breakout not yet confirmed (|momentum|={abs(or_momentum)} < 40)")

    # ── Recent 30-Min Momentum ──────────────────────────────────

    # #3 Recent direction alignment (+2, or −1 if against)
    if direction == "buy_call" and recent_dir == "bullish":
        score += 2
        confirmations.append(f"✅ Recent 30-min momentum is BULLISH ({recent_momentum:+d}) — aligned (+2)")
    elif direction == "buy_put" and recent_dir == "bearish":
        score += 2
        confirmations.append(f"✅ Recent 30-min momentum is BEARISH ({recent_momentum:+d}) — aligned (+2)")
    elif recent_dir == "neutral":
        cautions.append(f"⚠️ Recent 30-min momentum is NEUTRAL ({recent_momentum:+d}) — no current edge")
    else:
        score -= 1
        cautions.append(f"🚫 Recent 30-min momentum is {recent_dir.upper()} — AGAINST {direction.replace('_', ' ')} (−1)")

    # ── Daily Indicator Signals ─────────────────────────────────

    # #4 Volume surge (64.6% WR)
    vol_ratio = volume / volume_sma_20 if volume_sma_20 > 0 else 0
    if vol_ratio >= 1.2:
        score += 1
        confirmations.append(f"✅ Volume surge ({vol_ratio:.1f}× avg ≥ 1.2) — confirms participation (+1)")
    else:
        cautions.append(f"⚠️ Volume normal ({vol_ratio:.1f}× avg) — no surge")

    # #5 VIX elevated (57.9% WR)
    if vix > 18:
        score += 1
        confirmations.append(f"✅ VIX elevated ({vix:.1f} > 18) — wider ranges, better R:R (+1)")

    # #6 VWAP confirmation (54.7% WR)
    if direction == "buy_call" and current_price > sma_20:
        score += 1
        confirmations.append(f"✅ Above VWAP (${current_price:.2f} > SMA20 ${sma_20:.2f}) — buyers in control (+1)")
    elif direction == "buy_put" and current_price < sma_20:
        score += 1
        confirmations.append(f"✅ Below VWAP (${current_price:.2f} < SMA20 ${sma_20:.2f}) — sellers in control (+1)")
    else:
        side = "above" if current_price > sma_20 else "below"
        cautions.append(f"⚠️ Price {side} VWAP — against {direction.replace('_', ' ')} direction")

    # #7 Trend alignment (SMA20 vs SMA50)
    if direction == "buy_call" and sma_20 > sma_50:
        score += 1
        confirmations.append(f"✅ Trend aligned: SMA20 (${sma_20:.0f}) > SMA50 (${sma_50:.0f}) (+1)")
    elif direction == "buy_put" and sma_20 < sma_50:
        score += 1
        confirmations.append(f"✅ Trend aligned: SMA20 (${sma_20:.0f}) < SMA50 (${sma_50:.0f}) (+1)")
    else:
        cautions.append(f"⚠️ Trend not aligned (SMA20=${sma_20:.0f}, SMA50=${sma_50:.0f})")

    score = max(0, score)
    label = "🟢 HIGH" if score >= 6 else "🔵 MEDIUM" if score >= 3 else "🟡 LOW"

    return QualityResult(
        score=score,
        label=label,
        confirmations=confirmations,
        cautions=cautions,
    )

